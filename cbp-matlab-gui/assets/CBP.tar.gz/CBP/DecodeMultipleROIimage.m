clc, clear

inputs = {'max_100_components_2030.nii'};




load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
load(fullfile(pwd,'BrainMapData','Tasks.mat'))


for image = 1:numel(inputs)
    Vi = spm_vol(fullfile(pwd,'2decode',inputs{image}));
    
    dat = round(spm_read_vols(Vi));
    ind     = find(spm_read_vols(Vi)>0);
    [X Y Z] = ind2sub(Vi.dim,ind);
    label = dat(ind);
    VOImm  = Vi.mat * [X Y Z ones(size(Z))]'; clear X Y Z ind
    
    job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
    
    indices = unique(label);
    for index = 1:numel(indices)
        inFoci  = zeros(1,max(XYZ2EXP(4,:)));
        [~, D] = knnsearch(VOImm(1:3,label==indices(index))',XYZ2EXP(1:3,:)');
        
        inFoci(XYZ2EXP(4,(D-abs(det(Vi.mat(1:3,1:3)))^(1/3))<=0)) = 1;
        str = '0000'; str(end-numel(int2str(index))+1:end) = int2str(index);
        se_TaskInferenceLight(inFoci,['Label_' str],NaN,Experiments,job, spm_str_manip(inputs{image},'rt'));
        
    end

end
