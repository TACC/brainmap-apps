clc, clear

load ./BrainMapData/MetaMappingAnalysis.mat

load ./BrainMapData/SpecificTasks.mat    


histogram([AllPC.Available],'BinEdges',[0:2:900]); xlabel('Number of Experiments'); ylabel('Number of paradigm classes'); line([18 18],[0 6],'Color','r','LineWidth',2)
