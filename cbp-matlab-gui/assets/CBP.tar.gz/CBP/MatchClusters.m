function [T] = MatchClusters(T)

TT = T;

for i=2:size(T,1)
  clear n wo
  for ii=1:i
    n(:,ii) = hist(T(i,T(i-1,:)==ii),[1:i+1]);
    wo(ii)  = mean(find(T(i-1,:)==ii));
  end
  xn = sort(n,'descend');
  weig = xn(1,:)./xn(2,:);
  split    = find(weig==min(weig)); split = split(1);

  n(isnan(n)) = 0; 
  [B into] = sort(n(:,split),'descend'); into = into(1:2);
  mapping = [];
  for ii=1:i+1
    if ~any(into==ii)
      mapping(ii) = find(n(ii,:)==max(n(ii,:)));
    else
      if ii==into(1)
        mapping(ii) = split;
      else
        fill = ii;
      end
    end
  end
  mapping(fill) = i+1;
  
  if numel(unique(mapping)) ~= i+1
      n
  end
  for ii=1:(i+1)
    T(i,TT(i,:)==ii) = mapping(ii);
  end
   
end

