clc, clear

files = dir('./MACM/Judy/Sleuth/*.txt');
for i=1:numel(files)
    ROIs{i} = fullfile(pwd,'MACM/Judy/Sleuth',files(i).name);
end

try; delete('./MACM/Judy/Sleuth/Log.txt'); end
    diary('./MACM/Judy/Sleuth/Log.txt');
    diary on
    

project = 'Judy';

load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
load(fullfile(pwd,'BrainMapData','Tasks.mat'))
for i=2:size(ROIs,2)
    ROInow = deblank(ROIs{i}); printName = [spm_str_manip(ROInow,'rt')];
    
    SleuthExperiments = se_ReadSleuthTextFile(ROInow);
    
    fprintf(1,'%s\n',[printName ': ' int2str(numel(SleuthExperiments)) ' Experiments'])
    %            se_TaskInference(inFoci,printName,job(1).col,Experiments,job, project);
    se_computeALE(SleuthExperiments,printName,NaN, project);
    se_computeSALE2(SleuthExperiments,printName,NaN, project);
end
