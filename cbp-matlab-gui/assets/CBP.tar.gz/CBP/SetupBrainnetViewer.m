clc, clear


Vi = spm_vol(fullfile(pwd,'MaskenEtc','Schaefer_400_FSLMNI2mm.nii'));
dat = round(spm_read_vols(Vi)); ind  = find(spm_read_vols(Vi)>0); [X, Y, Z] = ind2sub(Vi.dim,ind); label = dat(ind); clear dat
VOImm  = Vi.mat * [X Y Z ones(size(Z))]'; clear X Y Z ind
labels = unique(label);
AnzR = numel(labels);


for roi = 1:AnzR
    idx = find(label == labels(roi));
    for i=1:100
        Voxel = VOImm(:,idx);
        D = ((pdist(Voxel')));
        DD = zscore(median(squareform(D)));
        out = find(DD==max(DD));
        isout (i) = max(DD);
        if max(DD)>2.5
            idx(out) = [];
        else
            break
        end
    end
    D = ((pdist(Voxel')));
    DD = zscore(mean(squareform(D)));
    in = find(DD==min(DD));
    XYZ(:,roi) = VOImm(1:3,idx(in));
end


fid = fopen('S400.node','w+');
for roi = 1:AnzR
   fprintf(fid,'%2.0f\t%2.0f\t%2.0f\t%2.0f\t%2.0f\t%s\n',XYZ(1,roi),XYZ(2,roi),XYZ(3,roi),1,1,'-');
end
fclose(fid);


try
    load S400neighborhood
catch
    for roi1 = 1:AnzR-1
        for roi2 = roi1+1:AnzR
            if min(min(pdist2(VOImm(1:3,label == labels(roi1))',VOImm(1:3,label == labels(roi2))')))<4
                notNeighbor(roi1,roi2) = 0;
            else
                notNeighbor(roi1,roi2) = 1;
            end
            notNeighbor(roi2,roi1) = notNeighbor(roi1,roi2);
        end
    end
    save S400neighborhood notNeighbor
end

load MACMnull2.mat; NullMACM(:,:,end+1) = MACM; NullMACM(:,:,end+1) = 0;

Z = norminv(mean(NullMACM<MACM,3)); Z(MACM==0) = 0; Z(eye(size(Z))==1) = 0; Z(notNeighbor==0) = 0;
for i=1:size(MACM,1)-1; for ii=i+1:size(MACM,1); MACM(ii,i) = MACM(i,ii); Z(ii,i) = Z(i,ii); end; end
Z2 =double( MACM .*(Z==max(Z(:)))); Z2(Z2>.0002) = .0002;

dlmwrite('S400_MACMmax.edge',Z2,'\t');

degree = (sum(Z2>0));


for k=2:10
    C      = linkage(-Z,'ward');
    figure(99), subplot(1,2,1); dendrogram(C,400)
    T = cluster(C,'maxclust',k);
    [~, I] = sort(T); clusters = T;
    % figure(99), subplot(1,2,1); imagesc(Z(I,I));
    % colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; [0 0 0]; [linspace(0,1,100); linspace(0,0,100); linspace(0,0,100)]'])
    
    
    fid = fopen(['S400_' int2str(k) 'c.node'],'w+');
    for roi = 1:AnzR
        fprintf(fid,'%2.0f\t%2.0f\t%2.0f\t%2.0f\t%2.0f\t%s\n',XYZ(1,roi),XYZ(2,roi),XYZ(3,roi),clusters(roi),degree(roi)/10,'-');
    end
    fclose(fid);
    BrainNet_MapCfg(fullfile(spm_str_manip(which('BrainNet'),'h'),'Data','SurfTemplate','BrainMesh_ICBM152.nv'),['S400_' int2str(k) 'c.node'],'visualizeOptions.mat',['S400_' int2str(k) '.jpg']);
end





BrainNet_MapCfg(fullfile(spm_str_manip(which('BrainNet'),'h'),'Data','SurfTemplate','BrainMesh_ICBM152.nv'),'S400_6c.node','S400_MACMmax.edge','visualizeOptions.mat'); 


