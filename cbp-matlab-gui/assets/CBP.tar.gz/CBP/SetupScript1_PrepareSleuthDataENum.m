clc, clear
global defaults, spm_defaults
spm_figure('GetWin','Interactive');



fid    = fopen('simon_func_mni_2019_Feb_19.txt'); % spm_select(1,'any','Select speadsheet','',pwd,'.txt'));

TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));

Exlines = struct('BMid',{});

cntExp  = 1; XYZ = [];
cntLine = 1;



while feof(fid) == 0
    line = fgetl(fid);
    
    if numel(line)>0
        try
            line = strrep(line,', ',',');
            
            [buffer line] = strtok(line,9);
            Exlines(cntLine).BMid = str2num(buffer);
            
            [buffer line]  = strtok(line,9);
            Exlines(cntLine).EXid = str2num(buffer);
            
            [Exlines(cntLine).Author line]  = strtok(line,9);
            
            [Exlines(cntLine).Journal line]  = strtok(line,9);
            
            [buffer line] = strtok(line,9);
            Exlines(cntLine).Year = str2num(buffer);
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).Diagnosis = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).StimModality = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).StimType = buffer{1}';
            
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).RespModality = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).RespType = buffer{1}';
            
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).Instruction = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).ExtVariable = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',';'); 
            Exlines(cntLine).Space = buffer{1}{end};
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).Context = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).Modality = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).Contrast = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).PC = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            Exlines(cntLine).BD = buffer{1}';
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            if buffer{1}{1}=='Y'
                Exlines(cntLine).Type = 'Activations';
            elseif buffer{1}{1}=='N'
                Exlines(cntLine).Type = 'De-Activations';
            else
                ups
            end
            
            [buffer line] = strtok(line,9);
            buffer        = textscan(buffer,'%s','Delimiter',',');
            if buffer{1}{1}=='Y'
                Exlines(cntLine).Comparison = 'low-level';
            elseif buffer{1}{1}=='N'
                Exlines(cntLine).Comparison = 'high-level';
            else
                ups
            end
            
            [buffer line] = strtok(line,9);
            Exlines(cntLine).Subjects = str2num(buffer);
            
            XYZ = nan(1,3);
            [X line] = strtok(line,9); [Y line] = strtok(line,9); [Z line] = strtok(line,9);
            Exlines(cntLine).XYZ = [str2num(X) str2num(Y) str2num(Z)]';
            
            
            if cntLine>1
                cntExp = cntExp+1;
                if Exlines(cntLine).BMid==Exlines(cntLine-1).BMid & Exlines(cntLine).EXid==Exlines(cntLine-1).EXid
                    cntExp = cntExp-1;
                end
            end
            
            Exlines(cntLine).ExpCount  = cntExp;
            cntLine = cntLine+1;
        end
    end
end

fclose(fid);

%%

index       = [Exlines.ExpCount];
xleer       = zeros(31,31,31);  xleer(16,16,16) = 1;

clear Experiments; Experiments(1)         = Exlines(1);

for cntExp = 1:Exlines(end).ExpCount
    start = find(index==cntExp,1,'first');
    Experiments(cntExp)         = Exlines(start);
end

for cntExp = 1:Exlines(end).ExpCount
    start = find(index==cntExp,1,'first');
    
%     if strcmpi(Exlines(start).Space(1),'t')
%         Experiments(cntExp).XYZmm = my_tal2icbm_spm([[Exlines(index==cntExp).XYZ] nan(3,10)]);
%         Experiments(cntExp).XYZmm = Experiments(cntExp).XYZmm(:,~isnan(sum(Experiments(cntExp).XYZmm)));
%     else
        Experiments(cntExp).XYZmm   = ([Exlines(index==cntExp).XYZ]);
%     end
    
        
    if or(Experiments(cntExp).Subjects == 0, isnan(Experiments(cntExp).Subjects))
        if any([Exlines(index==cntExp).Subjects])
            Experiments(cntExp).Subjects = nanmean([Exlines(index==cntExp).Subjects]);
        else
            Experiments(cntExp).Subjects = 1;
        end
    end
        
    
    Experiments(cntExp).UncertainTemplates  =  (  5.7/(2*sqrt(2/pi))  * sqrt(8*log(2))) ;   % Assuming 5.7 mm ED between templates
    Experiments(cntExp).UncertainSubjects   =  (  11.6/(2*sqrt(2/pi))  * sqrt(8*log(2))) / sqrt(Experiments(cntExp).Subjects);   % Assuming 11.6 mm ED between matching points
    
    Experiments(cntExp).Smoothing = sqrt(Experiments(cntExp).UncertainSubjects.^2 + Experiments(cntExp).UncertainTemplates.^2);
    
    Experiments(cntExp).XYZ   = round(inv(TEMPLATE.mat) * [Experiments(cntExp).XYZmm; ones(1,size(Experiments(cntExp).XYZmm,2))]);
    Experiments(cntExp).XYZ(1,Experiments(cntExp).XYZ(1,:)>TEMPLATE.dim(1)) = TEMPLATE.dim(1);
    Experiments(cntExp).XYZ(2,Experiments(cntExp).XYZ(2,:)>TEMPLATE.dim(2)) = TEMPLATE.dim(2);
    Experiments(cntExp).XYZ(3,Experiments(cntExp).XYZ(3,:)>TEMPLATE.dim(3)) = TEMPLATE.dim(3);
    Experiments(cntExp).XYZ(Experiments(cntExp).XYZ<1) = 1;
    Experiments(cntExp).Kernel = single(MemSmooth64bit(xleer,Experiments(cntExp).Smoothing,struct('dim',[31 31 31],'mat',TEMPLATE.mat),zeros(31)));
    Experiments(cntExp).Peaks  = size(Experiments(cntExp).XYZ,2);
    
    Experiments(cntExp).Mapping = or(strcmpi(Experiments(cntExp).Modality,'fMRI'),strcmpi(Experiments(cntExp).Modality,'PET')) & ...
                                  Experiments(cntExp).Peaks<45 & Experiments(cntExp).Subjects>7 & Experiments(cntExp).Subjects<45 & ... 
                                  all(strcmpi(Exlines(start).Diagnosis,'Normals')) & all(strcmpi(Exlines(start).Context,'Normal Mapping'));
    
end


%%


Experiments = rmfield(Experiments,'ExpCount');


save(fullfile(pwd,'BrainMapData','MetaAnalysis.mat'),'Experiments')


Experiments = Experiments([Experiments.Mapping]>0);
Experiments = rmfield(Experiments,'Mapping');

save(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'),'Experiments')


clear; SetupScript2_setUpBD
clear; SetupScript3_setupCBP
clear; SetupScript4_PrecomputeReducedGrid; 
clear; SetupScript5_GetDistributions
