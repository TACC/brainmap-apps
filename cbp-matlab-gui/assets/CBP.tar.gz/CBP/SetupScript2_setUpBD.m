clc, clear
load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))


diary(fullfile(pwd,'BrainMapData','TaskCounts.txt'));
diary on;


AllTasks = {}; cnt = 1; A = {Experiments.BD};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(strcmpi(Tasks(i).Name,Experiments(ii).BD));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllBD= Tasks; fprintf(1,'\n\n\n')



AllTasks = {}; cnt = 1; A = {Experiments.PC};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(strcmpi(Tasks(i).Name,Experiments(ii).PC));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllPC= Tasks; fprintf(1,'\n\n\n')



AllTasks = {}; cnt = 1; A = {Experiments.StimModality};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).StimModality, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllStimModality= Tasks; fprintf(1,'\n\n\n')



AllTasks = {}; cnt = 1; A = {Experiments.StimType};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).StimType, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllStimType= Tasks; fprintf(1,'\n\n\n')



AllTasks = {}; cnt = 1; A = {Experiments.RespModality};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).RespModality, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllRespModality= Tasks; fprintf(1,'\n\n\n')


AllTasks = {}; cnt = 1; A = {Experiments.RespType};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).RespType, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllRespType= Tasks; fprintf(1,'\n\n\n')


AllTasks = {}; cnt = 1; A = {Experiments.Instruction};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).Instruction, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllInstruction= Tasks; fprintf(1,'\n\n\n')


AllTasks = {}; cnt = 1; A = {Experiments.Contrast};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).Contrast, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllContrast= Tasks; fprintf(1,'\n\n\n')


clear AllTasks A B I i ii finder cnt Tasks

save(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'),'Experiments')
save(fullfile(pwd,'BrainMapData','SpecificTasks.mat'),'AllBD','AllPC','AllContrast','AllInstruction','AllRespModality','AllRespType','AllStimModality','AllStimType')







AllTasks = {}; cnt = 1; A = {Experiments.BD};
for i=1:numel(A); for ii=1:numel(A{i}); AllTasks{cnt,1} = A{i}{ii}; cnt = cnt+1; end; end
AllTasks = unique(AllTasks); Tasks = cell2struct(AllTasks,'Name',2); 

for i = 1:numel(Tasks)
    finder = zeros(size(Experiments));
    for ii = 1:numel(Experiments)
        finder(ii) = any(find(cellfun('length',strfind(Experiments(ii).BD, Tasks(i).Name))));
    end
    Tasks(i).Experiments = find(finder>0);
    Tasks(i).Available   = sum(finder>0);
end

[B I] = sort([Tasks.Available],'descend'); Tasks = Tasks(I);
for i = 1:numel(Tasks); fprintf(1,'%s\n',[int2str(Tasks(i).Available) ' Experiments for ' Tasks(i).Name]); end

AllBD= Tasks; fprintf(1,'\n\n\n')


clear Experiments
save(fullfile(pwd,'BrainMapData','Tasks.mat'))

diary off;
