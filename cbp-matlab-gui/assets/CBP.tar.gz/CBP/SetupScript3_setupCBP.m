load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))

XYZ2EXP = [];
for i=1:numel(Experiments)
  XYZ2EXP = [XYZ2EXP [Experiments(i).XYZmm; i*ones(1,size(Experiments(i).XYZ,2)); ((Experiments(i).Smoothing./sqrt(8*log(2)) + eps).^2)*ones(1,size(Experiments(i).XYZ,2))]];
end

save(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'),'XYZ2EXP')
  
