clc,clear

load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))

TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));

xleer      = spm_read_vols(spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii')))>0.1;
xleer2     = single(zeros(TEMPLATE.dim));

xleer2(1:2:end,1:2:end,1:2:end) = 1;
GMindices = find(xleer.*xleer2);

[X Y Z] = ind2sub(TEMPLATE.dim,find(xleer.*xleer2));
GMxyz = [X Y Z]'; clear X Y Z
GMmm  = TEMPLATE.mat * [GMxyz; ones(1,size(GMxyz,2))];
GMmm  = GMmm(1:3,:)';
clear xleer xleer2

MAmaps = nan(max(XYZ2EXP(4,:)),size(GMmm,1));

XYZ2EXP = XYZ2EXP';

for i=1:max(XYZ2EXP(:,4))
  Q = find(XYZ2EXP(:,4)==i);
  [IDX,Dist] = knnsearch(XYZ2EXP(Q,1:3),GMmm);
  MAmaps(i,:) = spm_Npdf(Dist,0,XYZ2EXP(Q(1),5));
end

MAmaps = 1-single(MAmaps);
save(fullfile(pwd,'BrainMapData','MAmaps.mat'),'MAmaps','GMmm','GMxyz')


