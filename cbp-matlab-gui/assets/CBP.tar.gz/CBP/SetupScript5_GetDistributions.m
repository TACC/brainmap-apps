load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))

load(fullfile(pwd,'MaskenEtc','permSpace.mat'))
TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));
prior    = spm_read_vols(TEMPLATE)>.1;

AnzV     = numel(Experiments);
xleer    = zeros(TEMPLATE.dim);

for i=1:AnzV
    for ii = 1:Experiments(i).Peaks
        xleer(Experiments(i).XYZ(1,ii),Experiments(i).XYZ(2,ii),Experiments(i).XYZ(3,ii)) = ...
            xleer(Experiments(i).XYZ(1,ii),Experiments(i).XYZ(2,ii),Experiments(i).XYZ(3,ii)) +1;
    end
end

xleer(~prior) = 0;


Vo       = TEMPLATE;
Vo.fname = fullfile(pwd,'MaskenEtc','FociSpace.nii');
Vo.dt    = [64 1];
Vo       = rmfield(Vo,'pinfo');
Vo       = spm_write_vol(Vo,xleer);

se_render_imageCol(Vo(1).fname,0,0,nan)
print('-dpng',fullfile(pwd,'MaskenEtc','FociSpace.png'))


allBM    = [Experiments.XYZ]; 

save(fullfile(pwd,'BrainMapData','permSpace.mat'),'allBM','allXYZ','anzXYZ','indice0','indices')


