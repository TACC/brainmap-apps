tic; clear s T ref TT

try; v = zeros(10,1); parfor u=1:10; v(u) = 1; end; clear u v; useParallel=1; catch; useParallel = 0; end
Vs = {'MACM','exMACM','MASP'};

if ~exist(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} ],'DATA',['Correspondenz_' int2str(clusters) '.mat']),'file')
    
    if exVOI<2
        
        intra_inter = nan(numel(xfoci),2);
        T = nan(numel(xfoci),size(VOImm,2));
        s = nan(numel(xfoci),size(VOImm,2));
        
        tic
        parfor run = 1:numel(xfoci)
            tmp = load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_' 'Top' int2str(xfoci(run)) '_' Vs{exVOI+1}]));
            VdatReal = tmp.VdatReal; tmp = [];
            VdatReal = VdatReal(:,(sum(isnan(VdatReal))==0));
            VdatReal  = bsxfun(@minus,VdatReal,nanmean(VdatReal,2));
            VdatReal  = single(bsxfun(@rdivide,VdatReal,max(nanstd(VdatReal,0,2),1)));
            
            [yC, D, T(run,:), ~] = yael_kmeans (VdatReal', clusters, 'redo', kiter, 'verbose', 0, 'seed', 0, 'niter', 255, 'init', 0);
            
            intra_inter(run,:)  = [mean(real(sqrt(D))) mean(pdist(yC','Euclidean'))];
            
            DD = real(sqrt(yael_L2sqr (VdatReal',VdatReal')));
            DD(eye(size(DD))==1) = 0; DD = squareform(DD);
            s(run,:) = silhouette([],T(run,:),DD);
            fprintf(1,'%s\n',[int2str(clusters) ' -> ' int2str(xfoci(run)) ' computed']);
            
        end
        
        MeanSolution = mode(T);
        for run = 1:numel(xfoci)
            tmp = T(run,:); T(run,:) = nan;
            [Acc,rand_index,match]= AccMeasure(MeanSolution,tmp);
            for xi=1:size(match,2);  T(run,tmp==match(2,xi)) = xi; end
        end

        MeanSolution = mode(T);
        for run = 1:numel(xfoci)
            tmp = T(run,:); T(run,:) = nan;
            [Acc,rand_index,match]= AccMeasure(MeanSolution,tmp);
            for xi=1:size(match,2);  T(run,tmp==match(2,xi)) = xi; end
        end

        save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']),'T','s','intra_inter')
        fprintf(1,'%s\n',[int2str(clusters) ' cluster solution computed in ' num2str(toc/60,'%3.1f') ' minutes'])
        
    else
        
        intra_inter = nan(1,2);
        T = nan(1,size(VOImm,2));
        s = nan(1,size(VOImm,2));
        t = nan(1,1);
        
        load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} ],'DATA','MASP.mat'));
        
        if clusters == maxClust
            if exist(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_s.mat']))~=2
                A =  squareform(pdist(VdatReal,'correlation'));
                save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_s']),'A');
            end
        end
        
        if useParallel>0
            [T(1,:),C,sumd,D] = kmeans(VdatReal,clusters,'distance','correlation','emptyaction','singleton','start','cluster','replicates',kiter,...
                'options',statset('UseParallel','always','MaxIter',1023));
        else
            [T(1,:),C,sumd,D] = kmeans(VdatReal,clusters,'distance','correlation','emptyaction','singleton','start','cluster','replicates',kiter,...
                'options',statset('MaxIter',1023));
        end
        
        intra_inter(1,:)  = [mean(D(sub2ind(size(D),1:size(D,1),T(1,:)))) mean(pdist(C,'correlation'))];
        s(1,:) = silhouette(VdatReal,T(1,:),'correlation');
        t(1) = toc;
        
        save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']),'T','s','intra_inter')
        fprintf(1,'%s\n',[int2str(clusters) ' computed in ' num2str(t(1)/60,'%3.1f') ' minutes']); tic
        
        
    end
end