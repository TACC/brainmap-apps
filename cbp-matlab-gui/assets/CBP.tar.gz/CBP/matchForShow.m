function II = matchForShow(T,nn)


 mn = max(T(:));

xn = []; for i1=1:mn; for i2=1:mn; for i3=1:mn; for i4=1:mn; for i5=1:mn; for i6=1:mn; for i7=1:mn
                            va = [i1 i2 i3 i4 i5 i6 i7];
                            if numel(unique(va(1:mn)))==mn; xn = [xn; va(1:mn) 0 0]; if nn(2)>0; xn = [xn; va(1:mn) mode(T(end,T(nn(2),:)==nn(10))) nn(2)-1]; xn = [xn; va(1:mn) -mode(T(end,T(nn(2),:)==nn(10))) nn(2)-1]; end; end
                        end; end; end; end; end; end; end
xn    = unique(xn,'rows');

for i=1:size(xn,1)
    II = [];
    for ii=1:mn
        if abs(xn(i,mn+1))==ii
            ind = find(T(end,:)==xn(i,ii));
            if sign(xn(i,mn+1))>0;  [b ii] = sort(T(xn(i,mn+2),ind),'ascend');
            else;                   [b ii] = sort(T(xn(i,mn+2),ind),'descend');
            end;                     II = [II ind(ii)];
        else
            II = [II find(T(end,:)==xn(i,ii))];
        end
    end
    xT = T(:,II); qc(i) = sum(sum(diff(xT')~=0));
end

xn    = unique(xn(find(qc==min(qc)),:),'rows');
xn = xn(1,:); II = [];
for ii=1:mn
    if abs(xn(1,mn+1))==ii
        ind = find(T(end,:)==xn(1,ii));
        if sign(xn(1,mn+1))>0;  [b ii] = sort(T(xn(1,mn+2),ind),'ascend');
        else                    [b ii] = sort(T(xn(1,mn+2),ind),'descend');
        end;                    II = [II ind(ii)];
    else
        II = [II find(T(end,:)==xn(1,ii))];
    end
end

