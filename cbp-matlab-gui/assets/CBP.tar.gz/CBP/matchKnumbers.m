function T = matchKnumbers(T,ref)

TT = T;
for i = 1:size(T,1)
    
    try
        clear n
        for ii=1:max(ref)
            n(ii,:) = hist(ref(T(i,:)==ii),[1:max(ref)]);
        end
        mapping = [];
        for ii=1:max(ref);
            mapping(ii) = find(n(:,ii)==max(n(:,ii)));
        end
        if numel(unique(mapping))<max(ref)
            n = n./repmat(sum(n)',1,size(n,2));
            for ii=1:max(ref)
                mapping(ii) = find(n(:,ii)==max(n(:,ii)));
            end
        end
        if numel(unique(mapping))==max(ref)
            for ii=1:max(ref)
                T(i,TT(i,:)==ii) = find(mapping==ii);
            end
        else
            for ii=1:max(ref)
                if numel(find(mapping==ii))==1
                    T(i,TT(i,:)==ii) = find(mapping==ii);
                elseif numel(find(mapping==ii))==2
                    wahl = find(mapping==ii);
                    T(i,TT(i,:)==ii) = wahl(find(max(n(:,wahl))==max(max(n(:,wahl)))));
                else
                    doppelt = find(hist(mapping,[1:max(ref)])==max(hist(mapping,[1:max(ref)])));
                    wahl = [];
                    for xi = 1:numel(doppelt)
                        wahl = [wahl find(mapping==doppelt(xi))];
                    end
                    T(i,TT(i,:)==ii) = wahl(find(max(n(:,wahl))==min(max(n(:,wahl)))));
                end
            end
        end
    end
end
