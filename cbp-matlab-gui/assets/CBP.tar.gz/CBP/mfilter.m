function out = mfilter(in,width,type)

if size(in,1)>1 & size(in,2)==1
    in = in';
end

if nargin<2
    width = 1;
end

if nargin<3
    type = 1;
end

if numel(width)==1
    width = [width width];
end

out = zeros(size(in));

for i=1:size(in,1)
    for ii=1:size(in,2)
        tmp = in(max(i-width(1),1):min(i+width(1),size(in,1)),max(ii-width(2),1):min(ii+width(2),size(in,2)));
        tmp = tmp(:); tmp(isnan(tmp))=[];
        if type == 1
            out(i,ii) = median(tmp);
        elseif type==2
            out(i,ii) = mean(tmp);
        end
    end
end




