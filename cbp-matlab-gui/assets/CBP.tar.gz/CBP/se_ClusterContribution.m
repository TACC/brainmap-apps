function se_ClusterContribution(Experiments,label, project)


[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'Contribution'));

AnzV     = numel(Experiments);
TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));
prior    = spm_read_vols(TEMPLATE)>.1;


xleer      = zeros(TEMPLATE.dim+[30 30 30]);

for i=1:AnzV
    data   = xleer;
    for ii = 1:Experiments(i).Peaks
        data(Experiments(i).XYZ(1,ii):Experiments(i).XYZ(1,ii)+30,Experiments(i).XYZ(2,ii):Experiments(i).XYZ(2,ii)+30,Experiments(i).XYZ(3,ii):Experiments(i).XYZ(3,ii)+30) = ...
            max(data(Experiments(i).XYZ(1,ii):Experiments(i).XYZ(1,ii)+30,Experiments(i).XYZ(2,ii):Experiments(i).XYZ(2,ii)+30,Experiments(i).XYZ(3,ii):Experiments(i).XYZ(3,ii)+30),Experiments(i).Kernel);
    end
    Experiments(i).dat    = data(16:end-15,16:end-15,16:end-15);
    Experiments(i).Author    = ['BMid: ' int2str(Experiments(i).BMid) '.' int2str(Experiments(i).EXid)];
end




fil = dir(fullfile(pwd,'MACM',project,'Results',[label '_cFWE*.nii']));


if numel(fil)>0
    
    fid = fopen(fullfile(pwd,'MACM',project,'Contribution',[spm_str_manip(fil.name,'rt') '_contribution.txt']),'wt');
    
    Vi = spm_vol(fullfile(pwd,'MACM',project,'Results',fil(1).name));
    dat = spm_read_vols(Vi);
    
    
    ind = find(dat>0);
    [X Y Z] = ind2sub(Vi.dim,ind);
    A = spm_clusters([X Y Z]');
    dat = accumarray([X Y Z],A,Vi.dim);
    
    cl  = unique(dat(dat>0));
    
    ALE  = spm_read_vols(spm_vol(fullfile(pwd,'MACM',project,'ALEvolumes',[label '.nii'])));
    ALEZ = spm_read_vols(spm_vol(fullfile(pwd,'MACM',project,'ALEvolumesZ',[label '.nii'])));
    
    
    for i=1:numel(cl)
        
        ind     = find(dat==cl(i));
        
        if numel(ind)>4
            
            [X Y Z] = ind2sub(Vi.dim,ind);
            XYZ = median((Vi.mat * [X Y Z ones(numel(X),1)]')');
            
            
            fprintf(fid,'\n\n%s\n',['Cluster ' int2str(i) ': ' int2str(numel(ind)) ' voxel [Center: ' int2str(XYZ(1)) '/' int2str(XYZ(2)) '/' int2str(XYZ(3)) ']'  ]);
            
            [N,maxZ,maxM,A,XYZ] = spm_max(ALEZ(ind),[X Y Z]');
            [maxZ I] = sort(maxZ,'descend');
            maxM = maxM(:,I);
            maxM = Vi.mat * [maxM; ones(1,size(maxM,2))];
            
            fprintf(fid,'\n%s\n','Local Maxima:');
            for ii=1:numel(maxZ)
                fprintf(fid,'%s\n',[ '[' int2str(maxM(1,ii)) ' / ' int2str(maxM(2,ii)) ' / ' int2str(maxM(3,ii)) ']:  Z=' num2str(maxZ(ii),'%2.1f') ]);
            end
            
            fprintf(fid,'\n');
            
            
            
            Ax = [];
            for ii=1:numel(Experiments);
                Ax(ii,:) = Experiments(ii).dat(ind);
            end
            AxF = 1-prod(1-Ax);
            
            if max(abs([AxF - ALE(ind)']))>eps
                error('ALE does not match union of MA-maps. Aborting')
            end
            
            for ii=1:numel(Experiments);
                    AxR = 1-prod(1-Ax([1:numel(Experiments)]~=ii,:),1);
                
                wig = sum(Experiments(ii).dat(ind));
                if (100*(1-mean(AxR./AxF)))>.1
                    stx = repmat(' ',1,max(cellfun('length',{Experiments.Author})));
                    stx(1:numel(Experiments(ii).Author)) = Experiments(ii).Author;
                    if max(100*(1-(AxR./AxF))) > 5
                        fprintf(fid,'%s\t%7.3f\t%7.3f\t%7.2f\t%7.2f\t%s\n',stx,wig, 100*wig/numel(ind),  100*(1-mean(AxR./AxF)),max(100*(1-(AxR./AxF))),['(' int2str(Experiments(ii).Subjects) ')']  );
                    end
                end
                
            end
        else
            fprintf(fid,'\n\n%s\n',['Cluster ' int2str(i) ]);
            fprintf(fid,'%s\n','Less than 5 voxels');
        end
    end
else
    fid = fopen(fullfile(pwd,'MACM',project,'Contribution',[label '_contribution.txt']),'wt');
    fprintf(fid,'%s\n','No significant clusters found');
end


status = fclose(fid);





