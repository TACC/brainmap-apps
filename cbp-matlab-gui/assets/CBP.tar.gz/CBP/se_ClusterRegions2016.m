clc, clear

Ni = dir('./VOIs/JuliaMDN_150/*.mat');

load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
load(fullfile(pwd,'BrainMapData','Tasks.mat'))
load(fullfile(pwd,'BrainMapData','MAmaps.mat'))
load(fullfile(pwd,'BrainMapData','SpecificTasks.mat'))

for Anz = 100:10:200
    
    clear VdatReal Functional Name jobs iNFoci D mD
    parfor i=1:numel(Ni);
        Name{i} = strrep(strrep(strrep(Ni(i).name,'sp.mat',''),'Left','L'),'Right','R');
        jobs{i} = load(fullfile(pwd,'VOIs/JuliaMDN_150',Ni(i).name));
        jobs{i}.job(1).Number = Anz;
        inFoci{i} = se_parseJob(jobs{i}.job, XYZ2EXP, AllBD);
        VOImm = str2num(jobs{i}.job(1).VOIs{1}); welche = find(inFoci{i}>0); xD = nan(1,numel(welche));
        for f = 1:numel(welche); xD(f) = min(pdist2(VOImm,Experiments(welche(f)).XYZmm(1:3,:)')); end
        D{i} = xD; mD(i) = mean(xD); % Distances are inflated since they don't acknowledge the 2 mm grid
        VdatReal(i,:) = 1-prod(MAmaps(inFoci{i}>0,:));
        
        [BDprofile, PCprofile] = se_TaskInference(inFoci{i},Name{i},NaN,Experiments,jobs{i}.job, '');
        Functional(i,:) = [BDprofile(:,1); PCprofile(:,1)]';
    end
    Functional = Functional(:,[AllBD.Available AllPC.Available]>50);
    Functions  = {AllBD([AllBD.Available]>50).Name AllPC([AllPC.Available]>50).Name};
    
    % AllBD(find(BDprofile(:,2)>.05)).Name
    
    
    xA = pdist(VdatReal,'Euclidean');
    YY = mdscale(xA,2,'criterion','sammon');
    figure(97), clf; subplot(2,2,1); scatter(YY(:,1),YY(:,2),'w'), set(gca,'xlim',[min(YY(:,1))-2 max(YY(:,1))+2],'ylim',[min(YY(:,2))-1 max(YY(:,2))+1])
    for i=1:numel(inFoci)
        text(YY(i,1),YY(i,2),Name{i},'VerticalAlignment','middle','HorizontalAlignment','center','Color','k');
    end;  title('Co-activation: ED / Sammon');
    
    Z = linkage(xA,'ward');
    figure(97),subplot(2,2,2); dendrogram(Z,numel(inFoci),'orientation','right','Labels',Name); title('Co-activation: ED / Ward');
    
    
    xA = pdist(Functional,'Euclidean');
    YY = mdscale(xA,2,'criterion','sammon');
    figure(97), subplot(2,2,3); scatter(YY(:,1),YY(:,2),'w'), set(gca,'xlim',[min(YY(:,1))-2 max(YY(:,1))+2],'ylim',[min(YY(:,2))-1 max(YY(:,2))+1])
    for i=1:numel(inFoci)
        text(YY(i,1),YY(i,2),Name{i},'VerticalAlignment','middle','HorizontalAlignment','center','Color','k');
    end; title('Functions: ED / Sammon');
    
    Z = linkage(xA,'ward');
    figure(97),subplot(2,2,4); dendrogram(Z,numel(inFoci),'orientation','right','Labels',Name); title('Functions: ED / Ward');
    
    set(gcf,'Position',[1 70 1388 733],'Color','w');
    export_fig(['Julia_' int2str(Anz)]);
    
end