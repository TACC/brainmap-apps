function se_SpecifyCBP2(varargin)

warning off

if (nargin==0),
    Action = 'draw';
else
    Action = varargin{1};
end

switch lower(Action),
    
    case 'draw'
        spm_figure('Clear','Graphics');
        spm('CreateIntWin','on');
        fg = spm_figure('GetWin','Graphics');
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .93 .8 .05],'string',{'Setup project'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''setup'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .86 .8 .05],'string',{'Compute connectivity matrices'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''conmat'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .79 .8 .05],'string',{'Perform kMeans Clustering'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''kmeans'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .65 .8 .05],'string',{'Select "nearest X" filters to include'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''solqual'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .58 .8 .05],'string',{'Select number of clusters'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''hierarchy'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .72 .8 .05],'string',{'Show diagnostics'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''dx'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .51 .8 .05],'string',{'Output solution'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''output'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .44 .8 .05],'string',{'Perform MACM on clusters'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''macm'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .37 .8 .05],'string',{'MACM contrast at splits'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''contrast'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .30 .8 .05],'string',{'MACM contrast final clusters'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyCBP2(''finals'')','foregroundcolor','k','FontSize',18);
        
        
        
        
    case 'setup'
        
        ROInow    = spm_vol(spm_select(Inf,'image','Select VOI mask file'));
        voi       = spm_str_manip(ROInow.fname,'rt');
        exVOI     = spm_input('VOI as target?','!+1','b',{'Yes','No','Only'},[0 1 2],1);
        filterVOI = spm_input('Median-filter VOI?','!+1','b',{'No','Yes'},[0 1],1);
        onlyGM    = spm_input('Use GM mask?','!+1','b',{'No','Yes'},[0 1],1);
        xfoci     = [];
        
        TEMPLATE = spm_vol('FociSpace.nii');
        
        [X Y Z] = ind2sub(ROInow.dim,find(spm_read_vols(ROInow)>0));
        VOIxyz = [X Y Z ones(size(Z))]'; clear X Y Z
        VOIxyz = unique(round(TEMPLATE.mat \ ROInow.mat * VOIxyz)','rows')';
        VOI    = accumarray(VOIxyz(1:3,:)',1,TEMPLATE.dim);
        
        GM      = spm_get_data(spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii')),VOIxyz);
        VOIxyz  = VOIxyz(:,GM>.1);
        
        if filterVOI>0
            out = zeros(size(VOI));
            for x=min(VOIxyz(1,:))-2:max(VOIxyz(1,:))+2
                for y=min(VOIxyz(2,:))-2:max(VOIxyz(2,:))+2
                    for z=min(VOIxyz(3,:))-2:max(VOIxyz(3,:))+2
                        tmp = VOI(x-2:x+2,y-2:y+2,z-2:z+2); tmp = tmp(:);
                        tmp2 = VOI(x-1:x+1,y-1:y+1,z-1:z+1); tmp2 = tmp2(:);
                        
                        if VOI(x,y,z) >0 & sum(tmp2)>9
                            out(x,y,z) = 1;
                        elseif (median(tmp)>eps)
                            out(x,y,z) = 1;
                        else
                            tmp = VOI(x-1:x+1,y-1:y+1,z-1:z+1); tmp = tmp(:);
                            if (median(tmp)>eps)
                                out(x,y,z) = 1;
                            end
                        end
                    end
                end
            end
            VOI = out;
            clear out x y z tmp
        end
        Vs = {'MACM','exMACM','MASP'};
        [s,mess,messid] = mkdir(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}]));
        [s,mess,messid] = mkdir(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA'));
        clear s mess messid
        
        xVo        = TEMPLATE;
        xVo.dt     = [2 1];
        xVo        = rmfield(xVo,'pinfo');
        xVo.fname  = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],[voi  '_VOImask.nii']);
        xVo        = spm_write_vol(xVo,VOI);
        
        Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE')
        
        spm('alert',{'Project set up !','',fullfile(pwd,'CBP',[voi  '_' Vs{exVOI+1} '.mat']),''})
        
        
        
    case 'conmat'
        
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        try; v = zeros(10,1); parfor u=1:10; v(u) = 1; end; clear u v; useParallel=1; catch; useParallel = 0; end
        tmp = load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'));
        XYZ2EXP = tmp.XYZ2EXP; clear tmp;
        
        
        Vs = {'MACM','exMACM','MASP'}; VOI = spm_read_vols(spm_vol(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],[voi '_VOImask.nii'])));
        
        [X Y Z] = ind2sub(TEMPLATE.dim,find(VOI));
        VOIxyz = [X Y Z]'; clear X Y Z
        VOImm  = TEMPLATE.mat * [VOIxyz; ones(1,size(VOIxyz,2))];
        clear VOI X Y Z xVo
        Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm')
        
        if exVOI<2 & isempty(xfoci); xfoci     = spm_input('Specify "nearest X"','!+1','e',[20:2:200]); end
        if exVOI==0
            tmp = load(fullfile(pwd,'BrainMapData','MAmaps.mat');
            GMmm   = tmp.GMmm;
            GMxyz  = tmp.GMxyz;
            MAmaps = tmp.MAmaps; clear tmp;
        else
            tmp = load(fullfile(pwd,'BrainMapData','MAmaps.mat');
            GMmm   = tmp.GMmm;
            GMxyz  = tmp.GMxyz; clear tmp;        
        end
        
        
        fprintf(1,'%s\n',['Starting connectivity modelling'])
        
        
        if exVOI == 0
            
            for run = 1:numel(xfoci)
                tic
                if exist(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} ],'DATA',[voi '_' 'Top' int2str(xfoci(run))   '_' Vs{exVOI+1} '.mat']))~=2
                    VdatReal = nan(size(VOIxyz,2),size(GMxyz,2),'single');
                    if useParallel==1
                        parfor vox = 1:size(VOImm,2)
                            D          = ((XYZ2EXP(1,:)-VOImm(1,vox)).^2+(XYZ2EXP(2,:)-VOImm(2,vox)).^2+(XYZ2EXP(3,:)-VOImm(3,vox)).^2);
                            [buffer Q] = sort(D,'ascend');
                            Q          = Q(1:round(xfoci(run)*1.5));
                            w               = spm_Npdf(sqrt(D(Q)),0,XYZ2EXP(5,Q));
                            [buffer, m]     = unique(XYZ2EXP(4,Q),'first');
                            [w II]          = sort(w(m),'descend');
                            VdatReal(vox,:) = 1-prod(MAmaps(buffer(II(1:min(numel(II),xfoci(run)))),:));
                        end
                    else
                        for vox = 1:size(VOImm,2)
                            D          = ((XYZ2EXP(1,:)-VOImm(1,vox)).^2+(XYZ2EXP(2,:)-VOImm(2,vox)).^2+(XYZ2EXP(3,:)-VOImm(3,vox)).^2);
                            [buffer Q] = sort(D,'ascend');
                            Q          = Q(1:round(xfoci(run)*1.5));
                            w               = spm_Npdf(sqrt(D(Q)),0,XYZ2EXP(5,Q));
                            [buffer, m]     = unique(XYZ2EXP(4,Q),'first');
                            [w II]          = sort(w(m),'descend');
                            try
                                VdatReal(vox,:) = 1-prod(MAmaps(buffer(II(1:min(numel(II),xfoci(run)))),:));
                            catch
                                ups
                            end
                        end
                    end
                    Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} ],'DATA',[voi '_' 'Top' int2str(xfoci(run))  '_' Vs{exVOI+1}]),'VdatReal');
                end
                fprintf(1,'%s\n',['Filter-size ' int2str(xfoci(run)) ' finished in ' num2str(toc/60,'%3.1f') ' minutes'])
            end
            
            
        elseif exVOI == 1
            
            Q = zeros(1,numel(xfoci));
            for run = 1:numel(xfoci)
                if exist(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_' 'Top' int2str(xfoci(run))  '_' Vs{exVOI+1} '.mat']),'file')==2;
                    Q(run) = 1;
                end
            end
            
            if ~all(Q>0)
                allVdatReal = nan(size(VOIxyz,2),size(GMxyz,2),numel(xfoci),'single');
                for vox = 1:size(VOImm,2)
                    tic
                    allD = sqrt((XYZ2EXP(1,:)-VOImm(1,vox)).^2+(XYZ2EXP(2,:)-VOImm(2,vox)).^2+(XYZ2EXP(3,:)-VOImm(3,vox)).^2);
                    D = zeros(1,max(XYZ2EXP(4,:)));
                    W = zeros(1,max(XYZ2EXP(4,:)));
                    N = cell(2,max(XYZ2EXP(4,:)));
                    for i=1:max(XYZ2EXP(4,:));
                        Q = XYZ2EXP(4,:)==i;
                        if sum(Q) == 1
                            W(i) = 0;
                        else
                            W(i)   = spm_Npdf(min(allD(Q)),0,XYZ2EXP(5,i));
                            N{1,i} = find(Q);
                            N{2,i} = spm_Npdf(allD(Q),0,XYZ2EXP(5,i));
                        end
                    end % 10s
                    [B I] = sort(W,'descend');
                    for run = 1:numel(xfoci)
                        thres = B(xfoci(run)); MA = cell(xfoci(run),1); Q = cell(xfoci(run),1); fwhm = nan(1,xfoci(run));
                        for i=1:xfoci(run)
                            try
                                xQ = N{1,I(i)}(N{2,I(i)}<thres); Q{i} = XYZ2EXP(1:3,xQ)'; fwhm(i) = XYZ2EXP(5,xQ(1));
                            catch
                                fwhm(i) = 0;
                            end
                        end
                        
                        myGMmm = single(GMmm);
                        if useParallel
                            parfor i=1:xfoci(run)
                                if fwhm(i)>0
                                    [~, Dist] = knnsearch(Q{i},myGMmm);
                                    MA{i,1} = spm_Npdf(Dist',0,fwhm(i));
                                else
                                    MA{i,1} = zeros(1,size(myGMmm,1));
                                end
                            end
                        else
                            for i=1:xfoci(run)
                                if fwhm(i)>0
                                    [~, Dist] = knnsearch(Q{i},myGMmm);
                                    MA{i,1} = spm_Npdf(Dist',0,fwhm(i));
                                else
                                    MA{i,1} = zeros(1,size(myGMmm,1));
                                end
                            end
                        end
                        allVdatReal(vox,:,run) = 1-prod(1-cell2mat(MA));
                    end
                    fprintf(1,'%s\n',['Voxel ' int2str(vox) ' / ' int2str(size(VOImm,2)) ' finished in ' num2str(toc,'%3.0f') ' sec'])
                end
                
                for run = 1:numel(xfoci)
                    VdatReal = squeeze(allVdatReal(:,:,run));
                    Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_' 'Top' int2str(xfoci(run))  '_' Vs{exVOI+1}]),'VdatReal');
                end
            end
            
        elseif exVOI == 2
            
            [~, Dist] = knnsearch(VOImm(1:3,:)',XYZ2EXP(1:3,:)');
            
            w = spm_Npdf(Dist',0,XYZ2EXP(5,:));
            Q = unique(XYZ2EXP(4,Dist<2));
            
            VdatReal = nan(size(VOIxyz,2),numel(Q),'single');
            
            for i=1:numel(Q)
                [~, Dist] = knnsearch(XYZ2EXP(1:3,XYZ2EXP(4,:)==Q(i))',VOImm(1:3,:)');
                VdatReal(:,i) = spm_Npdf(Dist',0,mean(XYZ2EXP(5,XYZ2EXP(4,:)==Q(i))'));
            end
            
            figure(99), clf; subplot(2,3,1), imagesc(VdatReal); title('raw')
            A = ((corr(VdatReal')));
            r = reord((corr(VdatReal')+1),1);
            subplot(2,3,4); imagesc(A(r,r)); title('Voxel Cross-Correlation');
            
            AA = corr(VdatReal);
            rr = reord((corr(VdatReal)+1),1);
            subplot(2,3,2); imagesc(AA(rr,rr)); title('Experiment Cross-Correlation');
            subplot(2,3,5); imagesc(VdatReal(r,rr)); title('Sorted both');
            subplot(2,3,6);  plot(sum(VdatReal(r,:),2),numel(r):-1:1); title('Sum'); axis tight
            
            save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA','MASP.mat'),'VdatReal');
            print(99,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} ],'MASP.png'))
            delete(99)
            
        end
        
        Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm')
        spm('alert',{'Connectivity-matrices computed !','',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}]),''})
        
        
        
        
        
        
    case 'dx'
        
        box = [];
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        tmp = load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'));
        XYZ2EXP = tmp.XYZ2EXP; clear tmp;
        
        tmp = load(fullfile(pwd,'BrainMapData','MAmaps.mat');
        GMmm   = tmp.GMmm; 
        GMxyz  = tmp.GMxyz;
        MAmaps = tmp.MAmaps; clear tmp;
        
        Vs = {'MACM','exMACM','MASP'}; VOI = spm_read_vols(spm_vol(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],[voi '_VOImask.nii'])));
        
        if exVOI==1
            MAmaps = MAmaps(:,VOI(sub2ind(TEMPLATE.dim,GMxyz(1,:),GMxyz(2,:),GMxyz(3,:)))==0);
            GMmm   = GMmm(VOI(sub2ind(TEMPLATE.dim,GMxyz(1,:),GMxyz(2,:),GMxyz(3,:)))==0,:);
            GMxyz   = GMxyz(:,VOI(sub2ind(TEMPLATE.dim,GMxyz(1,:),GMxyz(2,:),GMxyz(3,:)))==0);
        end
        
        clear VOI X Y Z xVo; tic
        
        MeanD = nan(size(VOImm,2),numel(xfoci));
        MedianD = nan(size(VOImm,2),numel(xfoci));
        FociHits = nan(size(VOImm,2),1);
        try
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}], [voi '_dist.mat']))
        catch
            try
                v = zeros(10,1); parfor u=1:10; v(u) = 1; end; clear u v; useParallel = 1;
            catch
                useParallel = 0;
            end
            
            if useParallel==1
                for run = 1:numel(xfoci)
                    parfor vox = 1:size(VOImm,2)
                        D          = ((XYZ2EXP(1,:)-VOImm(1,vox)).^2+(XYZ2EXP(2,:)-VOImm(2,vox)).^2+(XYZ2EXP(3,:)-VOImm(3,vox)).^2);
                        [buffer Q] = sort(D,'ascend');
                        Q          = Q(1:round(xfoci(run)*1.5));
                        D          = sqrt(D(Q));
                        
                        if run==1; FociHits(vox) = sum(floor(D)<=2); end
                        MeanD(vox,run) = mean((D(1:xfoci(run))));
                        MedianD(vox,run) = median((D(1:xfoci(run))));
                        % foci per voxel !
                    end
                    fprintf(1,'%s\n',['Filter-size ' int2str(xfoci(run)) ' checked in ' num2str(toc/60,'%3.1f') ' minutes'])
                end
            else
                for run = 1:numel(xfoci)
                    for vox = 1:size(VOImm,2)
                        D          = ((XYZ2EXP(1,:)-VOImm(1,vox)).^2+(XYZ2EXP(2,:)-VOImm(2,vox)).^2+(XYZ2EXP(3,:)-VOImm(3,vox)).^2);
                        [buffer Q] = sort(D,'ascend');
                        Q          = Q(1:round(xfoci(run)*1.5));
                        D          = sqrt(D(Q));
                        
                        if run==1; FociHits(vox) = sum(floor(D)<=2); end
                        MeanD(vox,run) = mean((D(1:xfoci(run))));
                        MedianD(vox,run) = median((D(1:xfoci(run))));
                        % foci per voxel !
                    end
                    fprintf(1,'%s\n',['Filter-size ' int2str(xfoci(run)) ' checked in ' num2str(toc/60,'%3.1f') ' minutes'])
                end
            end
            
        end
        Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}], [voi '_dist.mat']),'FociHits')
        
        
        TEMPLATE = spm_vol('FociSpace.nii');
        dat = accumarray(VOIxyz(1:3,:)',FociHits,TEMPLATE.dim);
        Vo = TEMPLATE;
        Vo = rmfield(TEMPLATE,'pinfo');
        Vo.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}], ['FociPerVoxel.nii']);
        Vo = spm_write_vol(Vo,dat);
        
        TEMPLATE = spm_vol('FociSpace.nii');
        try
            dat = accumarray(VOIxyz(1:3,:)',mean(MeanD(:,box(2,1):box(2,2)),2)/2,TEMPLATE.dim);
        catch
            dat = accumarray(VOIxyz(1:3,:)',mean(MeanD,2)/2,TEMPLATE.dim);
        end
        Vo = TEMPLATE;
        Vo = rmfield(TEMPLATE,'pinfo');
        Vo.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}], ['MeanDistanceInVoxel.nii']);
        Vo = spm_write_vol(Vo,dat);
        
        
        
        figure(99), clf; set(gcf,'Position',[1 41 1440 784])
        subplot(2,2,1);
        plot(mean(MeanD),'r'); hold on; axis tight
        plot(mean(MeanD)+std(MeanD),':r'); hold on; axis tight
        plot(mean(MeanD)-std(MeanD),':r'); hold on; axis tight
        set(gca,'XTick',[1:5:200], 'XTickLabel',xfoci([1:5:end]),'FontSize',6); grid on
        title(['Average +/. SD distance of the assigned foci']); xlabel('Filter (nearest experiments)'); ylabel('Distance in mm');
        
        try
            line([box(2,1) box(2,1)],[0 100])
            line([box(2,2) box(2,2)],[0 100])
        end
        
        
        figure(99), subplot(2,2,2);
        plot(mean(MeanD/2),'r'); hold on; axis tight
        plot(mean(MeanD/2)+std(MeanD/2),':r'); hold on; axis tight
        plot(mean(MeanD/2)-std(MeanD/2),':r'); hold on; axis tight
        set(gca,'XTick',[1:5:200], 'XTickLabel',xfoci([1:5:end]),'FontSize',6); grid on
        title(['Average +/. SD distance of the assigned foci']); xlabel('Filter (nearest experiments)'); ylabel('Distance in voxel');
        
        try
            line([box(2,1) box(2,1)],[0 100])
            line([box(2,2) box(2,2)],[0 100])
        end
        
        figure(99); subplot(2,2,3)
        try; hist(FociHits,0:max(FociHits)); axis tight; end
        title(['Number of foci in each voxel']); xlabel('Number of foci'); ylabel('Number of Voxel');
        
        
        passt = nan(numel(xfoci),maxClust);
        for clusters = 2:maxClust
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']))
            for run = 7:numel(xfoci)-8
                passt(run,clusters) = sum(mode(T(run-1:run,:))~=mode(T(run+1:run+2,:))); %/size(T,2)*100;
            end
            figure(98)
            if maxClust<=7, subplot(2,3,clusters-1);
            elseif maxClust<=9, subplot(2,4,clusters-1);
            elseif maxClust<=11, subplot(2,5,clusters-1);
            end
            title(['k = ' int2str(clusters)]);
            [B II] = sort(mode(T));
            imagesc(T(:,II)); set(gca,'XTick',[]);
            set(gca,'YTick',[1:5:100], 'YTickLabel',xfoci(1:5:end))
            title([int2str(clusters) ' cluster solution']); ylabel('Filter (nearest experiments)'); xlabel('Voxels within ROI');
            set(gca,'FontSize',7);
        end
        
        print(98,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],['kMeans_Overview.png']))
        
        figure(99), subplot(2,8,13:15); imagesc(passt);
        set(gca,'YTick',[1:5:100], 'YTickLabel',xfoci([1:5:end])); xlim([2 maxClust])
        title(['Change in assignment at filter size']); xlabel('Number of clusters'); ylabel('Filter size');
        
        figure(99), subplot(2,8,16); passt(isnan(passt)) = 0;
        plot(median(passt(2:end,:)'),1:size(passt,1)), set(gca,'ydir','reverse'), axis tight
        set(gca,'YTick',[1:5:100], 'YTickLabel',xfoci([1:5:end]));
        title(['Median across clusters']);
        print(99,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],['Diagnostics_upK' int2str(maxClust) '.png']))
        
        
        
        
        
        
        
        
        
    case 'kmeans'
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        maxClust = spm_input('Max # of clusters','!+1','e',9,1);
        if ~exist('kiter','var')
            kiter = spm_input('Replicates','!+1','e',100,1);
            Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm','maxClust','kiter')
        end
        
        for clusters = 2:1:maxClust
            doKmeans2
        end
        spm('alert',{'kMeans clustering completed !','',fullfile(pwd,'CBP',[voi '_CBP.mat']),''})
        

        
        
    case 'solqual'
        
        Vs = {'MACM','exMACM','MASP'};
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        for clusters = 2:maxClust
            if ~exist(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']),'file')
                spm('alert*',{'Please compute all cluster-solutions first !','',''})
                return
            end
        end
        
        priorFilter = spm_input('A priori filter','!+1','e',[xfoci(1) xfoci(end)],2);
        priorFilter = [find((xfoci-priorFilter(1))==min(abs(xfoci-priorFilter(1)))) find((xfoci-priorFilter(2))==min(abs(xfoci-priorFilter(2))))];
        
        figure(99), % Display summary image of the clustering results
        set(gcf,'Position',[1 41 1440 784])
        for clusters = 2:maxClust
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']))
            T = T(priorFilter(1):priorFilter(2),:);
            if maxClust<=7, subplot(2,3,clusters-1);
            elseif maxClust<=9, subplot(2,4,clusters-1);
            elseif maxClust<=11, subplot(2,5,clusters-1);
            end
            title(['k = ' int2str(clusters)]);
            [B II] = sort(mode(T));
            imagesc(T(:,II)); set(gca,'XTick',[]);
            set(gca,'YTick',[1:5:100], 'YTickLabel',xfoci(priorFilter(1):5:priorFilter(2)))
            for i=1:size(T,1)
                QC(clusters-1,i) = sum(T(i,:) ~=mode(T));
            end
            title([int2str(clusters) ' cluster solution']); ylabel('Filter (nearest experiments)'); xlabel('Voxels within ROI');
            set(gca,'FontSize',7);
        end
        
        print(99,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],['kMeans_Overview__' int2str(xfoci(priorFilter(1))) '_' int2str(xfoci(priorFilter(2))) '.png']))
        
        
        fine = 0; first = 1;
        box = [];
        originalQC = QC;
        while fine==0
            
            a = get(0,'screenSize'); figure(98); clf; set(gcf,'Position',[400 41 a(3)-400 a(4)-71])
            
            QC = originalQC;
            QC = (QC-mean(QC(:)))/std(QC(:));
            QC = mfilter(QC,[0 1]);
            figure(98), subplot(2,2,1), imagesc(QC);
            set(gca,'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'YTick',[1:size(QC,1)],'YTickLabel',[1:size(QC,1)]+1,'FontSize',8)
            ylabel('Number of clusters'); xlabel('Filter size')
            title('Proportion of deviants');
            
            QC = QC .* repmat([size(QC,1):-1:1]',1,size(QC,2))/sum([size(QC,1):-1:1]);
            QCr = mfilter(sum(QC),[1 1],2);
            figure(98), subplot(2,2,2), cla, plot(QCr,'k'), hold on; axis tight
            set(gca,'XLim',[0.5 size(QC,2)+.5],'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'FontSize',8)
            title('Weighted sum across clusters'); ylabel('z-scores');
            line([0 100],[0 0],'Color','r','LineStyle',':')
            line([0 100],[-0.5 -0.5],'Color','r','LineStyle','--')
            
            figure(98), subplot(2,2,3), cla,  imagesc(sqrt(sum(QC)-min(sum(QC)))), axis tight; set(gca,'YTick',100)
            set(gca,'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'FontSize',8), title('Weighted sum of z-scores')
            
            OK0 = find(QCr<0);
            OK0 = OK0 + priorFilter(1) -1;
            OK1 = find(QCr<-0.5); if numel(OK1)==0; OK1=NaN; end
            OK1 = OK1 + priorFilter(1) -1;
            
            try
                figure(98), subplot(2,2,4), cla
                text(.5,.5,{...
                    ['Weighted sum of z-scores < 0: [' int2str(xfoci(OK0(1))) ' ' int2str(xfoci(OK0(end))) '] -> ' int2str(numel(OK0)) ' filter-sizes'];'';...
                    ['Weighted sum of z-scores < -0.5: [' int2str(xfoci(OK1(1))) ' ' int2str(xfoci(OK1(end))) '] -> ' int2str(numel(OK1)) ' filter-sizes']},...
                    'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',10), axis off
            catch
                OK1 = [1 numel(QCr)];
            end
            
            
            ia = spm('CreateIntWin'); set(ia,'position',[10 43 378 373]);
            if first == 0
                for i=[1 3]
                    figure(98), subplot(2,2,i); y = get(gca,'ylim');
                    line([box(2,1)-.5 box(2,1)-.5]-priorFilter(1)+1,[y(1) y(2)],'Color','w','LineWidth',2)
                    line([box(2,2)+.5 box(2,2)+.5]-priorFilter(1)+1,[y(1) y(2)],'Color','w','LineWidth',2)
                    set(gca,'ylim',y)
                end
                
                figure(98), subplot(2,2,2); y = get(gca,'ylim');
                line([box(2,1)-.5 box(2,1)-.5]-priorFilter(1)+1,[y(1) y(2)],'Color','k','LineWidth',1)
                line([box(2,2)+.5 box(2,2)+.5]-priorFilter(1)+1,[y(1) y(2)],'Color','k','LineWidth',1)
                    set(gca,'ylim',y)
                
            else
                box = [1 size(QC,1); (OK1(1)) (OK1(end))];
                first=0;
            end
            
            useFilter = spm_input('Specify min/max','!+1','e',[xfoci(box(2,1)) xfoci(box(2,2))],2);
            useFilter = [find((xfoci-useFilter(1))==min(abs(xfoci-useFilter(1)))) find((xfoci-useFilter(2))==min(abs(xfoci-useFilter(2))))];
            box = [1 size(QC,1); useFilter];
            
            
            QC = originalQC;
            QC = (QC-mean(QC(:)))/std(QC(:));
            QC = mfilter(QC,[0 1]);
            figure(98), subplot(2,2,1), imagesc(QC);
            set(gca,'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'YTick',[1:size(QC,1)],'YTickLabel',[1:size(QC,1)]+1,'FontSize',8)
            ylabel('Number of clusters'); xlabel('Filter size')
            title('Proportion of deviants');
            
            figure(98), subplot(2,2,2), cla, plot(QCr,'k'), hold on; axis tight
            set(gca,'XLim',[0.5 size(QC,2)+.5],'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'FontSize',8)
            title('Weighted sum across clusters'); ylabel('z-scores');
            line([0 100],[0 0],'Color','r','LineStyle',':')
            line([0 100],[-0.5 -0.5],'Color','r','LineStyle','--')
            
            figure(98), subplot(2,2,3), cla,  imagesc(sqrt(sum(QC)-min(sum(QC)))), axis tight; set(gca,'YTick',100)
            set(gca,'XTick',[1:5:100], 'XTickLabel',xfoci(priorFilter(1):5:priorFilter(2)),'FontSize',8), title('Weighted sum of z-scores')
            
            
                for i=[1 3]
                    figure(98), subplot(2,2,i); y = get(gca,'ylim');
                    line([box(2,1)-.5 box(2,1)-.5]-priorFilter(1)+1,[y(1) y(2)],'Color','w','LineWidth',2)
                    line([box(2,2)+.5 box(2,2)+.5]-priorFilter(1)+1,[y(1) y(2)],'Color','w','LineWidth',2)
                    set(gca,'ylim',y)
                end
            
                figure(98), subplot(2,2,2); y = get(gca,'ylim');
                line([box(2,1)-.5 box(2,1)-.5]-priorFilter(1)+1,[y(1) y(2)],'Color','k','LineWidth',1)
                line([box(2,2)+.5 box(2,2)+.5]-priorFilter(1)+1,[y(1) y(2)],'Color','k','LineWidth',1)
                    set(gca,'ylim',y)
            
            fine = spm_input('Accept ?','!+1','b',{'Yes','No'},[1 0],2);
        end
        
        print(98,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],['Filter_upK' int2str(maxClust) '_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2))) '.png']))
        Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}]),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm','maxClust','kiter','box')
        delete(98)
        delete(99)
        
        
        
    case 'hierarchy'
        
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        Vs = {'MACM','exMACM','MASP'}; if exVOI == 2; box = [1 maxClust-1; 1 1]; xfoci = 1;end
        
        cnt = 1;
        for clusters = 2:maxClust
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']))
            T = T(box(2,1):box(2,2),:);
            s = s(box(2,1):box(2,2),:);
            VI(cnt,:) = intra_inter(box(2,1):box(2,2),2)./intra_inter(box(2,1):box(2,2),1);
            for i=1:size(T,2)
                QV(cnt,i) = sum(T(:,i) ~=mode(T(:,i)));
                sV(cnt,i) = min(s(:,i),[],1);
                sX(cnt,i) = mean(s(:,i),1);
            end
            mT(cnt,:) = mode(T,1);
            allT{cnt} = T;
            alls{cnt} = s;
            cnt = cnt+1;
        end
        
        clear s T VOI
        
        
        works = zeros(1,maxClust);
        
        n2=[]; anzahlen = nan(numel(allT)+1,maxClust);
        
        for i = 2:maxClust
            [T nn index] = se_checkHierarchy(mT,i, struct('col',col,'QV',QV,'sV',sV,'VOIxyz',VOIxyz,'allow',1),onlyGM);
            n2(i-1,:) = nn(1:5);
            if numel(unique(T(end,:))) == i;
                works(i) = 1;
            end
            anzahlen(1:i,i) = hist(T(end,:),1:i);
        end
        anzahlen  = [nanmean(anzahlen); min(anzahlen)];
        
        allVIin = [];
        for i=1:numel(allT)
            VarInfo = [];
            for i1 = 1:size(allT{i},1)-1
                for i2 = i1+1:size(allT{i},1)
                    VarInfo = [VarInfo; se_varinfo(allT{i}(i1,:),allT{i}(i2,:))];
                end
            end
            allVIin = [allVIin VarInfo];
        end
        allVIin = [nan(size(allVIin,1),1) allVIin];
        
        allVIbetween = nan(size(allT{1},1),2);
        for i=1:numel(allT)-1
            VarInfo = [];
            for i1 = 1:size(allT{i},1)
                VarInfo = [VarInfo; se_varinfo(allT{i}(i1,:),allT{i+1}(i1,:))];
            end
            allVIbetween = [allVIbetween VarInfo];
        end
        
        allVIbetween2 = [nan(1,2)];
        for i=1:numel(allT)-1
            allVIbetween2 = [allVIbetween2 se_varinfo(mode(allT{i}),mode(allT{i+1}))];
        end
        
        QC = zeros(size(allT{1},1),numel(allT)+1);
        for i=1:numel(allT)
            for ii=1:size(allT{i},1)
                QC(ii,i+1) = sum(allT{i}(ii,:)~=mode(allT{i}))/size(allT{i},2)*100;
            end
            
        end
        
        
        
        
        ms = nan(size(alls{1},1),1);
        for i=1:numel(alls)
            ms(:,i+1) = mean(alls{i}');
        end
        
        
        lab = {}; for i=3:maxClust; lab{i-2} = ['->' int2str(i)]; end
        gut = zeros(8,maxClust);
        
        
        a = get(0,'screenSize');
        figure(99); clf; set(gcf,'Position',[400 41 a(3)-400 a(4)-70])
        if exVOI<2
            subplot(2,4,1), plot(mean(allVIin),'k','LineWidth',2); title('Variation of information between filter-sizes','FontSize',7); xlim([1.5 maxClust+.5]);  hold on;
            for i=2:maxClust
                line([i i],[mean(allVIin(:,i))+std(allVIin(:,i)) mean(allVIin(:,i))-std(allVIin(:,i))],'Color',[.5 .5 .5])
                if i>2
                    [h p]= ttest(allVIin(:,i)-allVIin(:,i-1),0,0.01,'right');
                    if h==0
                        text(i,mean(allVIin(:,i))+std(allVIin(:,i))*1.05,'n.s.','HorizontalAlignment','center')
                        gut(1,i) = 1;
                    end
                    
                end
            end
            set(gca,'XTick',2:maxClust);
        end
        
        
        subplot(2,4,5), cla, plot(mean(allVIbetween,1)','Color','k','LineWidth',2); title('Variation of information across clusters','FontSize',7); xlim([1.5 maxClust+.5]); hold on;
        for i=3:maxClust
            line([i i],[mean(allVIbetween(:,i))+std(allVIbetween(:,i)) mean(allVIbetween(:,i))-std(allVIbetween(:,i))],'Color',[0 0 0])
            if i<maxClust
                [h p]= ttest(allVIbetween(:,i+1)-allVIbetween(:,i),0,0.05,'right');
                if h==1
                    text(i+.5,(mean(allVIbetween(:,i))+mean(allVIbetween(:,i+1)))*0.55,'*','HorizontalAlignment','center')
                    gut(5,i) = 1;
                end
            end
            
            if i>3
                [h p]= ttest(allVIbetween(:,i)-allVIbetween(:,i-1),0,0.05,'left');
                if h==1
                    text(i-.5,(mean(allVIbetween(:,i))+mean(allVIbetween(:,i-1)))*0.55,'-','HorizontalAlignment','center')
                    gut(5,i) = gut(5,i)+0.5;
                end
            end
        end
        set(gca,'XTick',3:numel(allT)+1,'XTickLabel',lab)
        
        VxI = [nan(size(VI,2),1) VI'];
        subplot(2,4,3), cla, plot(mean(VxI,1)','Color','k','LineWidth',2); title('Inter/intra cluster distances','FontSize',7); hold on;   xlim([1.5 maxClust+.5])
        for i=2:maxClust
            line([i i],[mean(VxI(:,i))+std(VxI(:,i)) mean(VxI(:,i))-std(VxI(:,i))],'Color',[.5 0 0])
            if i>2
                [h p]= ttest(VxI(:,i)-VxI(:,i-1),0,0.05,'right');
                if h==1
                    text(i,mean(VxI(:,i))+std(VxI(:,i))*1.05,'*','HorizontalAlignment','center')
                    gut(3,i) = 1;
                end
            end
        end
        set(gca,'XTick',2:maxClust);
        
        VdI = [nan(size(VI,2),2) diff(VI)'];
        subplot(2,4,7), cla, plot(mean(VdI,1),'k','LineWidth',2);  title('Change in Inter/intra cluster distance','FontSize',7); hold on;   xlim([1.5 maxClust+.5])
        for i=3:maxClust
            line([i i],[mean(VdI(:,i))+std(VdI(:,i)) mean(VdI(:,i))-std(VdI(:,i))],'Color',[.5 0 0])
            if i<maxClust
                [h p]= ttest(VdI(:,i+1)-VdI(:,i),0,0.05,'right');
                if h==0
                    text(i+.5,(mean(VdI(:,i))+mean(VdI(:,i+1)))*.55,'n.s.','HorizontalAlignment','center')
                    gut(7,i) = 1;
                end
            end
        end
        set(gca,'XTick',3:numel(allT)+1,'XTickLabel',lab);
        
        np = [NaN; NaN; diff(n2(:,4))./n2(1:end-1,4)*-100]; warMax = 0;
        subplot(2,4,6), cla, plot(np,'k','LineWidth',2); title('Percentage of voxels not with parent','FontSize',7)
        set(gca,'XTick',3:numel(allT)+1,'XTickLabel',lab); xlim([1.5 maxClust+.5])
        for i=3:maxClust-1
            if i>3 & np(i)>np(i-1) & np(i)>np(i-2)
                warMax = 1;
            end
            if warMax==0 & np(i)<nanmedian(np)
                text(i,np(i)*.85,'_','HorizontalAlignment','center','FontSize',12)
                gut(6,i) = 1.5;
            end
        end
        
        
        
        subplot(2,4,2), cla, plot(mean(ms,1),'k','LineWidth',2); title('Average silhouette value','FontSize',7); xlim([1.5 maxClust+.5])
        for i=2:maxClust
            line([i i],[mean(ms(:,i))+std(ms(:,i)) mean(ms(:,i))-std(ms(:,i))],'Color',[.5 0 0])
            if i>2
                [h p]= ttest(ms(:,i)-ms(:,i-1),0,0.05,'right');
                if h==1
                    text(i,mean(ms(:,i))+std(ms(:,i))*1.05,'*','HorizontalAlignment','center')
                    gut(2,i) = 1;
                else
                    [h p]= ttest(ms(:,i)-ms(:,i-1),0,0.01,'left');
                    if h==0
                        text(i,mean(ms(:,i))+std(ms(:,i))*1.05,'n.s.','HorizontalAlignment','center')
                        gut(2,i) = 0.5;
                    end
                end
            end
        end
        set(gca,'XTick',2:maxClust);
        
        
        if exVOI < 2
            subplot(2,4,4), cla; plot(mean(QC),'k','LineWidth',2); title('Percentage of "missclassfied" voxels','FontSize',7); xlim([1.5 maxClust+.5])
            for i=2:maxClust
                line([i i],[mean(QC(:,i))+std(QC(:,i)) mean(QC(:,i))-std(QC(:,i))],'Color',[.5 0 0])
                if i>2
                    [h p]= ttest(QC(:,i)-QC(:,i-1),0,0.05,'right');
                    if h==0
                        text(i-.5,(mean(QC(:,i-1))+mean(QC(:,i)))*.65,'n.s.','HorizontalAlignment','center')
                        gut(4,i) = 1;
                    end
                    if i<maxClust
                        [h p]= ttest(QC(:,i+1)-QC(:,i),0,0.05,'right');
                        if h==1
                            text(i+.5,(mean(QC(:,i+1))+mean(QC(:,i)))*.55,'*','HorizontalAlignment','center')
                            gut(4,i) = gut(4,i)+.5;
                        end
                    end
                end
            end
            set(gca,'XTick',2:maxClust);
        end
        
        
        subplot(2,4,8), cla; bar(anzahlen'); title('Mean (blue), Min (red) voxel / cluster','FontSize',7); xlim([1.5 maxClust+.5])
        gut(8,:) = (anzahlen(2,:)./anzahlen(1,:))>.5;
        gut(8,anzahlen(2,:)==0)=-Inf;
        
        
        ia = spm('CreateIntWin'); set(ia,'position',[10 43 378 373]);
        takeK = spm_input('Chosen solution','!+1','e',find(sum(gut)==max(sum(gut))),1);
        
        box(1,2) = takeK;
        
        figure(99);Vs = {'MACM','exMACM','MASP'}; 
        for i = [2 3 5 6 7 8]; subplot(2,4,i), set(gca,'FontSize',7); end
        if exVOI<2; for i = [1 4]; subplot(2,4,i), set(gca,'FontSize',7); end; end
        print(99,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],['Hierarchy__upK' int2str(maxClust) '_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2))) '.png']))
        for i = 1:8; subplot(2,4,i), set(gca,'FontSize',10); end
        
        save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm','maxClust','kiter','box')
        delete(99)
        
        
        
    case 'output'
        
        load(spm_select(1,'mat','Select project matfile',[],fullfile(pwd,'CBP')));
        try, onlyGM; catch; onlyGM = 0; end; lrev = 2;
        Vs = {'MACM','exMACM','MASP'};
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        
        for clusters = 2:box(1,2)
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']))
            mT(clusters-1,:) = mode(T(box(2,1):box(2,2),:),1);
        end
        
        mT = MatchClusters(mT); mTkeep = mT;
        [T nn index] = se_checkHierarchy(mT(lrev-1:end,:)-(lrev-2),box(1,2)-(lrev-2), struct('col',col,'VOIxyz',VOIxyz),onlyGM);
        pT = mT(:,index);
        T = [mT(1:(lrev-2),index); T+(lrev-2)]; Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1} '.mat']),'exVOI','filterVOI','ROInow','onlyGM','xfoci','voi','TEMPLATE','VOIxyz','VOImm','maxClust','kiter','box','T')
        
        II = matchForShow(T,nn); figT = repmat(T,[1,1,3]); for ii=1:size(T,1); for xi=1:max(T(ii,:)); for c=1:3; figT(ii,T(ii,:) == xi,c) = col(xi,c); end; end; end
        
        a = get(0,'screenSize'); figure(97); set(gcf,'Position',[400 41 a(3)-400 a(4)-70]); subplot(2,2,2), image(figT(:,II,:))
        title('kMeans clustering'); xlabel([int2str(size(T,2)) ' voxels hierarchically consistent']), set(gca,'XTick',[])
        set(gca,'YTick',[1:box(1,2)-1],'YTickLabel',[1:box(1,2)-1]+1)
        
        
        dirname = [voi '_' Vs{exVOI+1} '_' int2str(box(1,2)) 'Clusters_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2)))];
        [s,mess,messid] = mkdir(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname));
        
        try
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'MDS.mat'))
            YY(size(mT,2),2)
        catch
            xA = zeros((size(mT,2)*(size(mT,2)-1))/2,box(2,2));
            parfor xrun = box(2,1):box(2,2)
                run = xrun
                tmp = load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',[voi '_' 'Top' int2str(xfoci(run)) '_' Vs{exVOI+1}]));
                VdatReal = tmp.VdatReal; tmp = [];
                VdatReal = VdatReal(:,(sum(isnan(VdatReal))==0));
                VdatReal  = bsxfun(@minus,VdatReal,nanmean(VdatReal,2));
                VdatReal  = single(bsxfun(@rdivide,VdatReal,max(nanstd(VdatReal,0,2),1)));
                A = yael_L2sqr(VdatReal',VdatReal');
                A((triu(ones(size(A))))==1) = 0; A = sqrt(A); A = A + A';
                
                xA(:,xrun) = squareform(A)';		% A enthaelt jeweils die cross-correlations matrix
            end
            
            xA(:,1:(box(2,1)-1)) = [];
            xA = squareform(ev(xA));
            xA = real(xA);
            
            YY = mdscale(xA,2,'criterion','sammon');
            Vs = {'MACM','exMACM','MASP'}; save(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'MDS.mat'),'YY','xA')
        end
        
        
        YY = YY(index,:);
        figure(97), subplot(2,2,1),scatter(YY(:,1),YY(:,2)), axis tight
        for i=1:max(T(end,:))
            scatter(YY(pT(end,:)==i,1),YY(pT(end,:)==i,2),'MarkerEdgeColor',col(i,:)), hold on;
        end; axis tight
        title('Multidimensional scaling (Sammon''s stress)')
        
        figure(97), subplot(2,2,3), imagesc(1-xA), colormap('default')
        title('Original similarity matrix'); xlabel('Individual voxels in the ROI');  ylabel('Individual voxels in the ROI');
        
        figure(97), subplot(2,2,4), imagesc(1-xA(index(II),index(II))), colormap('default')
        title('Reordered similarity matrix'); xlabel('Individual voxels in the ROI');  ylabel('Individual voxels in the ROI');
        
        
        print(97,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clustering_Results.png'));
        delete(97)
        
        
        
        figure(97), clf
        
        for l = 1:size(T,1)
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'MDS.mat'))
            subplot(2,size(T,1),l+size(T,1)),scatter(YY(:,1),YY(:,2)), axis tight
            for i=1:max(T(end,:))
                scatter(YY(mTkeep(l,:)==i,1),YY(mTkeep(l,:)==i,2),'MarkerEdgeColor',col(i,:)), hold on;
            end; axis tight
            title('Multidimensional scaling (Sammon''s stress) - Full')
            
            YY = YY(index,:);
            subplot(2,size(T,1),l), scatter(YY(:,1),YY(:,2)), axis tight
            for i=1:max(T(end,:))
                scatter(YY(pT(l,:)==i,1),YY(pT(l,:)==i,2),'MarkerEdgeColor',col(i,:)), hold on;
            end; axis tight
            title('Multidimensional scaling (Sammon''s stress)')
        end
        print(97,'-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'MDS-ByLevel.png'));
        
        
        
        
        
        
        TEMPLATE = spm_vol('FociSpace.nii');
        dat = accumarray(VOIxyz(1:3,index)',T(end,:),TEMPLATE.dim);
        Vo = TEMPLATE;
        Vo = rmfield(TEMPLATE,'pinfo');
        Vo.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['Parcellation.nii']);
        Vo = spm_write_vol(Vo,dat);
        
        try
            [X Y Z] = ind2sub(ROInow.dim,find(spm_read_vols(ROInow)>0));
        catch
            [X Y Z] = ind2sub(ROInow.dim,find(spm_read_vols(spm_vol(fullfile(pwd,'VOIs','VOIs4CBP',spm_str_manip(ROInow.fname,'t'))))>0));
        end
        xyz = [X Y Z]'; clear X Y Z
        dat = zeros(ROInow.dim);
        dat(sub2ind(ROInow.dim,xyz(1,:),xyz(2,:),xyz(3,:))) = round(spm_get_data(Vo,inv(Vo.mat) * ROInow.mat * [xyz; ones(1,size(xyz,2))]));
        
        Vi = rmfield(ROInow,'pinfo');
        Vi.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['ParcellationC.nii']);
        Vi = spm_write_vol(Vi,dat);
        delete(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['Parcellation.nii']))
        
        
        
        
        
        TEMPLATE = spm_vol('FociSpace.nii'); T = mTkeep;
        dat = accumarray(VOIxyz(1:3,:)',T(end,:),TEMPLATE.dim);
        Vo = TEMPLATE;
        Vo = rmfield(TEMPLATE,'pinfo');
        Vo.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['Parcellation.nii']);
        Vo = spm_write_vol(Vo,dat);
        
        
        try
            [X Y Z] = ind2sub(ROInow.dim,find(spm_read_vols(ROInow)>0));
        catch
            [X Y Z] = ind2sub(ROInow.dim,find(spm_read_vols(spm_vol(fullfile(pwd,'VOIs','VOIs4CBP',spm_str_manip(ROInow.fname,'t'))))>0));
        end
        xyz = [X Y Z]'; clear X Y Z
        dat = zeros(ROInow.dim);
        dat(sub2ind(ROInow.dim,xyz(1,:),xyz(2,:),xyz(3,:))) = round(spm_get_data(Vo,inv(Vo.mat) * ROInow.mat * [xyz; ones(1,size(xyz,2))]));
        
        Vi = rmfield(ROInow,'pinfo');
        Vi.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['ParcellationF.nii']);
        Vi = spm_write_vol(Vi,dat);
        delete(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['Parcellation.nii']))
        
        
        
        
        
        Vi = spm_vol(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname, ['ParcellationF.nii']));
        dat = round(spm_read_vols(Vi));
        
        
        [s,mess,messid] = mkdir(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters'));
        [s,mess,messid] = mkdir(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters','Location'));
        
        for i=1:max(T(end,:))
            Vo = rmfield(ROInow,'pinfo');
            Vo.fname = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(i) '.nii']);
            Vo = spm_write_vol(Vo,dat==i);
            
            [X Y Z] = ind2sub(Vi.dim,find(dat==i));
            xyz = [X Y Z]'; clear X Y Z
            fg = spm_figure('GetWin','Graphics'); spm_figure('Clear','Graphics'); spm_orthviews('Reset');
            spm_orthviews('Image', spm_vol('MNI152_T1_1mm_brain.nii'), [0.0 0.22 1 .8]);
            spm_orthviews('addcolouredblobs',1,xyz,1,Vi.mat,col(i,:));
            mXYZ = median([Vi.mat * [xyz; ones(1,size(xyz,2)) ]]');
            spm_orthviews('reposition',mXYZ(1:3));
            print('-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters','Location',['Cluster_' int2str(i)  '.png']));
        end
        
        
        setp = [4 4];
        if max(T(end,:)) <=12; setp = [4 3]; end
        if max(T(end,:)) <=9; setp = [3 3]; end
        if max(T(end,:)) <=8; setp = [2 4]; end
        if max(T(end,:)) <=6; setp = [2 3]; end
        if max(T(end,:)) <=4; setp = [2 2]; end
        if max(T(end,:)) <=2; setp = [1 2]; end
        
        for i=1:max(T(end,:))
            yc(i) = nanmean(VOIxyz(2,T(end,:)==i));
        end
        
        [B I]= sort(yc);
        for i=1:max(T(end,:))
            A = imread(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters','Location',['Cluster_' int2str(i)  '.png']),'png');
            figure(10); subplot(setp(1),setp(2),I(i)); image(A(100:560,1:460,:)), set(gca,'DataAspectRatio', [1 1 1]); axis off; title(['Cluster ' int2str(i)]);
        end
        print('-dpng',fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters','Location',['Summary.png'])); delete(10)
        
        se_SpecifyCBP2('draw')
        
        
        
    case 'macm'
        
        Vs = {'MACM','exMACM','MASP'};
        dirname = spm_select(1,'dir','Select results folder',[],fullfile(pwd,'CBP'));
        
        parts   = find(dirname==filesep); if max(parts) == numel(dirname); dirname  = dirname(1:end-1); parts = find(dirname==filesep); end
        dirname = dirname(parts(end)+1:end);
        
        parts   = find(dirname=='_');  in = strfind(dirname,'Clusters');
        load(fullfile(pwd,'CBP',[dirname(1:parts(find(abs(parts-in)==min(abs(parts-in))))-1) '.mat']));
        
        box(1,2) = str2double(dirname(parts(find(abs(parts-in)==min(abs(parts-in))))+1:in-1));
        in = strfind(dirname,'-');
        
        box(2,1) = find(xfoci==str2double(dirname(parts(end)+1:in(end)-1)));
        box(2,2) = find(xfoci==str2double(dirname(in(end)+1:end)));
        
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        dirname = [voi '_' Vs{exVOI+1} '_' int2str(box(1,2)) 'Clusters_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2)))];
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        for i=1:box(1,2)
            job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
            job(1).VOIs{1} = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(i) '.nii']);
            job(1).col = col(i,:);
            inFoci = se_parseJob(job, XYZ2EXP, AllBD);
            printName = ['Cluster' int2str(i)];
            
            se_makeWorkspace(Experiments(find(inFoci)),printName, dirname);
            fprintf(1,'%s\n',[printName ': ' int2str(numel(find(inFoci))) ' Experiments'])
            se_computeALE(Experiments(find(inFoci)),printName,job(1).col, dirname)
            se_TaskInference(inFoci,printName,job(1).col,Experiments,job, dirname);
        end
        se_SpecifyCBP2('draw')
        
        
    case 'contrast'
        dirname = spm_select(1,'dir','Select results folder',[],fullfile(pwd,'CBP'));
        Vs = {'MACM','exMACM','MASP'};
        
        parts   = find(dirname==filesep); if max(parts) == numel(dirname); dirname  = dirname(1:end-1); parts = find(dirname==filesep); end
        dirname = dirname(parts(end)+1:end);
        
        parts   = find(dirname=='_');  in = strfind(dirname,'Clusters');
        load(fullfile(pwd,'CBP',[dirname(1:parts(find(abs(parts-in)==min(abs(parts-in))))-1) '.mat']));
        
        for clusters = 2:box(1,2)
            load(fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],'DATA',['Correspondenz_' int2str(clusters) '.mat']))
            mT(clusters-1,:) = mode(T(box(2,1):box(2,2),:),1);
        end
        lrev = 2;; mT = MatchClusters(mT); mTkeep = mT;
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        [T nn index] = se_checkHierarchy(mT(lrev-1:end,:)-(lrev-2),box(1,2)-(lrev-2), struct('col',col,'VOIxyz',VOIxyz),onlyGM);
        pT = mT(:,index);
        T = [mT(1:(lrev-2),index); T+(lrev-2)];
        T = [ones(1,size(T,2)); T];
        
        box(1,2) = str2double(dirname(parts(find(abs(parts-in)==min(abs(parts-in))))+1:in-1));
        in = strfind(dirname,'-');
        
        box(2,1) = find(xfoci==str2double(dirname(parts(end)+1:in(end)-1)));
        box(2,2) = find(xfoci==str2double(dirname(in(end)+1:end)));
        
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        dirname = [voi '_' Vs{exVOI+1} '_' int2str(box(1,2)) 'Clusters_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2)))];
        
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        
        for clusters = 2:box(1,2)
            split = unique(T(clusters,T(clusters-1,:)==mode(T(clusters-1,find(T(clusters,:)==clusters)))));
            g = unique(T(end,T(clusters,:)==split(1))); str = [];
            job1 = struct('VOIs',cell(1,1),'within',2,'between',2,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
            for i=1:numel(g);
                str = [str; fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(g(i)) '.nii'])];
            end
            job1(1).VOIs{1} = str; job1(1).col = col(split(1),:);
            
            g = unique(T(end,T(clusters,:)==split(2))); str = [];
            job2 = struct('VOIs',cell(1,1),'within',2,'between',2,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
            for i=1:numel(g);
                str = [str; fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(g(i)) '.nii'])];
            end
            job2(1).VOIs{1} = str; job2(1).col = col(split(2),:);
            
            inFoci1 = se_parseJob(job1, XYZ2EXP, AllBD);
            printName1 = [int2str(clusters) '_Cluster' int2str(split(1)) ];
            inFoci2 = se_parseJob(job2, XYZ2EXP, AllBD);
            printName2 = [int2str(clusters) '_Cluster' int2str(split(2))];
            
            
            se_computeALE(Experiments(find(inFoci1)),printName1,job1(1).col, dirname)
            se_computeALE(Experiments(find(inFoci2)),printName2,job2(1).col, dirname)
            
            se_TaskInference(inFoci1,printName1,job1(1).col,Experiments,job1, dirname);
            se_TaskInference(inFoci2,printName2,job2(1).col,Experiments,job2, dirname);
            
            se_TaskInferenceDuo([inFoci1; inFoci2],{printName1; printName2},[job1(1).col; job2(1).col],Experiments,all(all([job1(1).FilterIn; job1(1).FilterOut]== [job2(1).FilterIn; job2(1).FilterOut])), dirname);
            
            dFoci = (inFoci1>0 & inFoci2>0);
            inFoci1(dFoci) = 0;
            inFoci2(dFoci) = 0;
            
            se_computeContrasts(Experiments(inFoci1>0), Experiments(inFoci2>0), printName1, printName2,[job1(1).col; job2(1).col], dirname)
            
        end
        
        se_SpecifyCBP2('draw')
        
        
        
        
    case 'finals'
        
        Vs = {'MACM','exMACM','MASP'};
        dirname = spm_select(1,'dir','Select results folder',[],fullfile(pwd,'CBP'));
        
        parts   = find(dirname==filesep); if max(parts) == numel(dirname); dirname  = dirname(1:end-1); parts = find(dirname==filesep); end
        dirname = dirname(parts(end)+1:end);
        
        parts   = find(dirname=='_');  in = strfind(dirname,'Clusters');
        load(fullfile(pwd,'CBP',[dirname(1:parts(find(abs(parts-in-1)==min(abs(parts-in-1))))-1) '.mat']));
        
        box(1,2) = str2double(dirname(parts(find(abs(parts-in)==min(abs(parts-in))))+1:in-1));
        in = strfind(dirname,'-');
        
        box(2,1) = find(xfoci==str2double(dirname(parts(end)+1:in(end)-1)));
        box(2,2) = find(xfoci==str2double(dirname(in(end)+1:end)));
        
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1]; % color definitions
        dirname = [voi '_' Vs{exVOI+1} '_' int2str(box(1,2)) 'Clusters_' int2str(xfoci(box(2,1))) '-' int2str(xfoci(box(2,2)))];
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        
        woIstWas = [];
        dieNamen = {};
        
        for cluster1 = 1:box(1,2)-1
            for cluster2 = cluster1+1:box(1,2)
                
                woIstWas = [woIstWas; cluster1 cluster2];
                
                job1 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job1(1).VOIs{1} = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(cluster1) '.nii']);
                job1(1).col = col(cluster1,:);
                
                job2 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job2(1).VOIs{1} = fullfile(pwd,'CBP',[voi '_' Vs{exVOI+1}],dirname,'Clusters',['Cluster' int2str(cluster2) '.nii']);
                job2(1).col = col(cluster2,:);
                
                printName1 = ['Cluster' int2str(cluster1)];
                printName2 = ['Cluster' int2str(cluster2)];
                
                dieNamen{end+1}  =   fullfile(pwd,'MACM',dirname,'Contrasts',[ printName1 '--' printName2  '_P95.nii']);
                
                inFoci1 = se_parseJob(job1, XYZ2EXP, AllBD);
                inFoci2 = se_parseJob(job2, XYZ2EXP, AllBD);
                
                se_computeALE(Experiments(find(inFoci1)),printName1,job1(1).col, dirname)
                se_computeALE(Experiments(find(inFoci2)),printName2,job2(1).col, dirname)
                
                se_TaskInferenceDuo([inFoci1; inFoci2],{printName1; printName2},[job1(1).col; job2(1).col],Experiments,all(all([job1(1).FilterIn; job1(1).FilterOut]== [job2(1).FilterIn; job2(1).FilterOut])), dirname);
                
                dFoci = (inFoci1>0 & inFoci2>0);
                inFoci1(dFoci) = 0;
                inFoci2(dFoci) = 0;
                
                se_computeContrasts(Experiments(inFoci1>0), Experiments(inFoci2>0), printName1, printName2,[job1(1).col; job2(1).col], dirname)
                
            end
        end
        
        
        [status,message,messageid] = mkdir(fullfile(pwd,'MACM',dirname,'Specifics'));
        [status,message,messageid] = mkdir(fullfile(pwd,'MACM',dirname,'Specifics','Images'));
        
        for cluster = 1:box(1,2)
            
            printName = ['Cluster' int2str(cluster)];
            fil = dir(fullfile(pwd,'MACM',dirname,'Results',[printName '*.nii']));
            Vi = spm_vol(fullfile(pwd,'MACM',dirname,'Results',fil(1).name));
            dat = spm_read_vols(Vi);
            
            for i=1:numel(dieNamen)
                if woIstWas(i,1) == cluster
                    dat = min(dat,spm_read_vols(spm_vol(dieNamen{i})));
                elseif woIstWas(i,2) == cluster
                    dat = min(dat,-1*spm_read_vols(spm_vol(dieNamen{i})));
                end
            end
            
            dat = dat.*(dat>0);
            
            ind = find(dat);
            [X Y Z] = ind2sub(Vi.dim,ind); z = dat(ind);
            A = spm_clusters([X Y Z]'); Q = [];
            for i=1:max(A)
                if sum(A==i)>50
                    Q = [Q find(A==i)];
                end
            end
            dat = zeros(size(dat));
            dat(ind(Q)) = z(Q);
            
            Vi.fname  = fullfile(pwd,'MACM',dirname,'Specifics',['Cluster' int2str(cluster) '.nii']);
            Vi = rmfield(Vi,'pinfo');
            Vi = spm_write_vol(Vi,dat);
            
            se_render_imageCol(Vi.fname,0,0,col(cluster,:))
            print('-dpng',fullfile(pwd,'MACM',dirname,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
            ImageCut(fullfile(pwd,'MACM',dirname,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']),'X');
            delete(fullfile(pwd,'MACM',dirname,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
            
            
            
        end
        
        
        se_SpecifyCBP2('draw')
        
        
        
        
        
        
end

