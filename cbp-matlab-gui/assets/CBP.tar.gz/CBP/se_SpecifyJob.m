function se_SpecifyJob(varargin)

global DJobs
if (nargin==0),
    Action = 'draw';
    DJobs = cell(10,2);
    
else,
    Action = varargin{1};
end

switch lower(Action),
    
    case 'draw'
        spm_figure('Clear','Graphics');
        spm('CreateIntWin','on');
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .94 .48 .05],'string',{'Individual MACM analyses'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''single'')','foregroundcolor','g','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .88 .8 .05],'string',{'Individual specific co-activations'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''sale'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .815 .8 .05],'string',{'Individual functional characterizations'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''bdio'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .765 .8 .05],'string',{'Functional characterizations of co-activation'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''bdiop'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .7 .8 .05],'string',{'Multi-contrast specific co-activations'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''specific'')','foregroundcolor','k','FontSize',18);
        
        
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.6 .94 .3 .05],'string',{'Evaluate VOIs'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''evaluate'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .587 .8 .06],'string',{'Compute MACM contrasts'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''difference'')','foregroundcolor','g','FontSize',18);
        
        for i=1:size(DJobs,1)
            for ii=1:2
                str = ['DJobs{' int2str(i) ',' int2str(ii) '}'];
                try; nam = spm_str_manip(DJobs{i,ii},'t');
                    uicontrol(fg,'style','pushbutton','units','normalized','position',[0.05+(ii-1)*.455 .59-(i*.042) .45 .035],'string',{nam},...
                        'horizontalalignment','center','fontweight','bold','foregroundcolor','k','FontSize',9,...
                        'callback',['global DJobs; ' str ' = se_select(1,''vois'',''Select mask-image or VOI-definition matfile''); se_SpecifyJob(''draw'')']);
                catch; nam = ' No VOI selected ';
                    uicontrol(fg,'style','pushbutton','units','normalized','position',[0.05+(ii-1)*.455 .59-(i*.042) .45 .035],'string',{nam},...
                        'horizontalalignment','center','foregroundcolor','k','FontSize',8,...
                        'callback',['global DJobs; ' str ' = se_select(1,''vois'',''Select mask-image or VOI-definition matfile''); se_SpecifyJob(''draw'')']);
                end
            end
        end
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .107 .8 .06],'string',{'Characterize functional differences'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''bdpc2'')','foregroundcolor','k','FontSize',18);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .025 .8 .06],'string',{'MACM network analysis'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyJob(''macmnet'')','foregroundcolor','g','FontSize',18);
        
    case 'difference'
        
        if max(min(cellfun('length',DJobs),[],2))>0
            
            project = spm_input('Project name',1,'s','');
            load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
            load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
            load(fullfile(pwd,'BrainMapData','Tasks.mat'))
            
            for i=1:size(DJobs,1)
                if min(numel(DJobs{i,1}),numel(DJobs{i,2}))>5
                    if ~strcmpi(DJobs{i,1}(end-2:end),'mat')
                        job1 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                        job1(1).VOIs{1} = DJobs{i,1};
                    else
                        load(DJobs{i,1})
                        job1=job;
                    end
                    if ~isfield(job1,'col'); job1(1).col = [1 0 0]; end
                    if any(isnan(job1(1).col)); job1(1).col = [1 0 0]; end
                    inFoci1 = se_parseJob(job1, XYZ2EXP, AllBD);
                    printName1 = [spm_str_manip(DJobs{i,1},'rt')];
                    
                    if ~strcmpi(DJobs{i,2}(end-2:end),'mat')
                        job2 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                        job2(1).VOIs{1} = DJobs{i,2};
                    else
                        load(DJobs{i,2})
                        job2=job;
                    end
                    if ~isfield(job2,'col'); job2(1).col = [0 1 0]; end
                    if any(isnan(job2(1).col)); job2(1).col = [0 1 0]; end
                    inFoci2 = se_parseJob(job2, XYZ2EXP, AllBD);
                    printName2 = [spm_str_manip(DJobs{i,2},'rt')];
                    
                    se_computeALE(Experiments(find(inFoci1)),printName1,job1(1).col, project)
                    se_computeALE(Experiments(find(inFoci2)),printName2,job2(1).col, project)
                    
                    se_TaskInference(inFoci1,printName1,job1(1).col,Experiments,job1, project);
                    se_TaskInference(inFoci2,printName2,job2(1).col,Experiments,job2, project);
                    
                    se_makeWorkspace(Experiments(find(inFoci1)),printName1, project);
                    se_makeWorkspace(Experiments(find(inFoci2)),printName2, project);
                    
                    if ~any(job1(1).FilterIn)  & ~any(any(job1(1).FilterOut)) ~any(job2(1).FilterIn)  & ~any(any(job2(1).FilterOut))
                        se_TaskInferenceDuo([inFoci1; inFoci2],{printName1; printName2},[job1(1).col; job2(1).col],Experiments,all(all([job1(1).FilterIn; job1(1).FilterOut]== [job2(1).FilterIn; job2(1).FilterOut])), project);
                    end
                    
                    dFoci = (inFoci1>0 & inFoci2>0);
                    inFoci1(dFoci) = 0;
                    inFoci2(dFoci) = 0;
                    
                    se_computeContrasts(Experiments(inFoci1>0), Experiments(inFoci2>0), printName1, printName2,[job1(1).col; job2(1).col], project)
                    
                end
            end
        end
        
        
        
    case 'bdiop'
        
        ROIs1 = se_select(Inf,'vois','1st set of mask-images or VOI-definition matfiles');
        ROIs2 = se_select(Inf,'vois','2nd set of mask-images or VOI-definition matfiles');
        project = spm_input('Project name',1,'s','');
        tolerance  = spm_input(['Tolerance in mm '],'+0','r',0,1);

        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        
        for i=1:size(ROIs1,1)
            for ii=1:size(ROIs2,1)
                ROInow = deblank(ROIs1(i,:));
                if ~strcmpi(ROInow(end-2:end),'mat')
                    job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',tolerance,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                    job(1).VOIs{1} = ROInow;
                else
                    load(ROInow)
                end
                inFoci1 = se_parseJob(job, XYZ2EXP, AllBD);
                
                ROInow = deblank(ROIs2(ii,:));
                if ~strcmpi(ROInow(end-2:end),'mat')
                    job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',tolerance,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                    job(1).VOIs{1} = ROInow;
                else
                    load(ROInow)
                end
                inFoci2 = se_parseJob(job, XYZ2EXP, AllBD);
                
                inFoci = (inFoci1>0 & inFoci2>0);
                printName = [spm_str_manip(deblank(ROIs1(i,:)),'rt') '_und_' spm_str_manip(deblank(ROIs2(ii,:)),'rt') '__' int2str(tolerance)];
                
            se_makeWorkspace(Experiments(find(inFoci)),printName, project);
            fprintf(1,'%s\n',[printName ': ' int2str(numel(find(inFoci))) ' Experiments']);
            se_TaskInference(inFoci,printName,NaN,Experiments,job, project);
            end
        end
        
         
         
         
        
    case 'bdpc2'
        
        
        if max(min(cellfun('length',DJobs),[],2))>0
            
            project = spm_input('Project name',1,'s','');
            load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
            load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
            load(fullfile(pwd,'BrainMapData','Tasks.mat'))
            
            for i=1:size(DJobs,1)
                if min(numel(DJobs{i,1}),numel(DJobs{i,2}))>5
                    if ~strcmpi(DJobs{i,1}(end-2:end),'mat')
                        job1 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                        job1(1).VOIs{1} = DJobs{i,1};
                    else
                        load(DJobs{i,1})
                        job1=job;
                    end
                    if ~isfield(job1,'col'); job1(1).col = [1 0 0]; end
                    if any(isnan(job1(1).col)); job1(1).col = [1 0 0]; end
                    inFoci1 = se_parseJob(job1, XYZ2EXP, AllBD);
                    printName1 = [spm_str_manip(DJobs{i,1},'rt')];
                    
                    if ~strcmpi(DJobs{i,2}(end-2:end),'mat')
                        job2 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                        job2(1).VOIs{1} = DJobs{i,2};
                    else
                        load(DJobs{i,2})
                        job2=job;
                    end
                    if ~isfield(job2,'col'); job2(1).col = [0 1 0]; end
                    if any(isnan(job2(1).col)); job2(1).col = [0 1 0]; end
                    inFoci2 = se_parseJob(job2, XYZ2EXP, AllBD);
                    printName2 = [spm_str_manip(DJobs{i,2},'rt')];
                                        
                    if ~any(job1(1).FilterIn)  & ~any(any(job1(1).FilterOut)) ~any(job2(1).FilterIn)  & ~any(any(job2(1).FilterOut))
                        se_TaskInferenceDuo([inFoci1; inFoci2],{printName1; printName2},[job1(1).col; job2(1).col],Experiments,all(all([job1(1).FilterIn; job1(1).FilterOut]== [job2(1).FilterIn; job2(1).FilterOut])), project);
                    end
                end
            end
        end
        
        
        
        
    case 'single'
        
        ROIs = spm_select(Inf,'any','Select mask-images or VOI-definition matfiles');
        
        project = spm_input('Project name',1,'s','');
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        for i=1:size(ROIs,1)
            ROInow = deblank(ROIs(i,:));
            if ~strcmpi(ROInow(end-2:end),'mat')
                job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job(1).VOIs{1} = ROInow;
            else
                load(ROInow)
            end
            
            if ~isfield(job,'col'); job(1).col = NaN; end
            inFoci = se_parseJob(job, XYZ2EXP, AllBD);
            printName = [spm_str_manip(ROInow,'rt')];
            se_makeWorkspace(Experiments(find(inFoci)),printName, project);
            fprintf(1,'%s\n',[printName ': ' int2str(numel(find(inFoci))) ' Experiments']);
            se_computeALE(Experiments(find(inFoci)),printName,job(1).col, project)
            se_ClusterContribution(Experiments(find(inFoci)),printName, project)
            se_TaskInference(inFoci,printName,job(1).col,Experiments,job, project);
        end
        
        se_SpecifyJob('draw')
        
        
    case 'evaluate'
        ROIs = se_select(Inf,'vois','Select mask-images or VOI-definition matfiles');
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        for xi=1:size(ROIs,1)
            ROInow = deblank(ROIs(xi,:));
            if ~strcmpi(ROInow(end-2:end),'mat')
                job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job(1).VOIs{1} = ROInow;
            else
                load(ROInow)
            end
            
            if ~isfield(job,'col'); job(1).col = NaN; end
            inFoci = se_parseJob(job, XYZ2EXP, AllBD);
            
            job  = job(cellfun('length',{job.VOIs})>0);
            for i=1:numel(job)
                
                for ii=1:size(job(i).VOIs{1},1)
                    if length(deblank(job(i).VOIs{1}(ii,:)))>3
                        name = deblank(job(i).VOIs{1}(ii,:));
                        if name(end)=='1'
                            name = strrep(name,',1','');
                        end
                        if max(strcmpi(name(end-2:end),{'img','nii','hdr'}))>0
                            Vi      = spm_vol(deblank(job(i).VOIs{1}(ii,:)));
                            ind     = find(spm_read_vols(Vi)>0);
                            [X Y Z] = ind2sub(Vi.dim,ind);
                            VOImm  = Vi.mat * [X Y Z ones(size(Z))]'; clear X Y Z ind
                        else
                            VOImm = str2num(job(i).VOIs{1}(ii,:))';
                            Vi.mat = eye(3);
                        end
                        
                        D = 0;
                        welche = find(inFoci>0);
                        for f = 1:numel(welche)
                            [A xD] = knnsearch(VOImm(1:3,:)',Experiments(welche(f)).XYZmm(1:3,:)');
                            D = max(D,min(xD-abs(det(Vi.mat(1:3,1:3)))^(1/3)));
                        end
                        
                    end
                end
            end
            
            
            printName = [spm_str_manip(ROInow,'rt')];
            fprintf(1,'%s\n',[printName ': ' int2str(numel(find(inFoci))) ' Experiments (' int2str(sum([Experiments(inFoci>0).Subjects])) ' subjects, ' int2str(size([Experiments(inFoci>0).XYZ],2)) ' foci)  [Dmax = ' num2str(D,'%2.1f') 'mm]'])
            
        end
        
        
    case 'bdio'
        
        ROIs = se_select(Inf,'vois','Select mask-images or VOI-definition matfiles');
        
        project = spm_input('Project name',1,'s','');
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        
        Q = zeros(size(ROIs,1),numel(Experiments));
        for i=1:size(ROIs,1)
            ROInow = deblank(ROIs(i,:));
            if ~strcmpi(ROInow(end-2:end),'mat')
                job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job(1).VOIs{1} = ROInow;
            else
                load(ROInow)
            end
            
            
            if ~isfield(job,'col'); job(1).col = NaN; end
            inFoci = se_parseJob(job, XYZ2EXP, AllBD);
            printName = [spm_str_manip(ROInow,'rt')];
            Q(i,inFoci>0) = 1;
            
%            AllBD = AllStimModality;
%            AllPC = AllStimType;
            
%            se_FunctionalDecoding(inFoci,printName,job(1).col,Experiments,job, project);
             se_TaskInference(inFoci,printName,job(1).col,Experiments,job, project);
             se_makeWorkspace(Experiments(find(inFoci)),printName, project);
            
        end
        
        se_SpecifyJob('draw')
        
        
        
    case 'specific'
        
        ROIs = se_select(Inf,'vois','Select mask-images or VOI-definition matfiles');
        
        project = spm_input('Project name',1,'s','');
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        col = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; .5 0 0; 0 0.5 0; 0 0 .5; 1 .5 0; 0 1 .5; .5 0 1; 1 0 .5; .5 1 0; 0 .5 1]; % color definitions
        woIstWas = []; dieNamen = {};
        
        for cluster1 = 1:size(ROIs,1)-1
            for cluster2 = cluster1+1:size(ROIs,1)
                
                woIstWas = [woIstWas; cluster1 cluster2];
                
                ROInow = deblank(ROIs(cluster1,:));
                if ~strcmpi(ROInow(end-2:end),'mat')
                    job1 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                    job1(1).VOIs{1} = ROInow;
                    job1(1).col = col(cluster1,:);
                else
                    load(ROInow); job1 = job;
                end
                
                ROInow = deblank(ROIs(cluster2,:));
                if ~strcmpi(ROInow(end-2:end),'mat')
                    job2 = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                    job2(1).VOIs{1} = ROInow;
                    job2(1).col = col(cluster2,:);
                else
                    load(ROInow); job2 = job;
                end
                
                printName1 = spm_str_manip(deblank(ROIs(cluster1,:)),'rt');
                printName2 = spm_str_manip(deblank(ROIs(cluster2,:)),'rt');;
                
                dieNamen{end+1}  =   fullfile(pwd,'MACM',project,'Contrasts',[ printName1 '--' printName2  '_P95.nii']);
                
                inFoci1 = se_parseJob(job1, XYZ2EXP, AllBD);
                inFoci2 = se_parseJob(job2, XYZ2EXP, AllBD);
                
                se_TaskInference(inFoci1,printName1,job1(1).col,Experiments,job1, project);
                se_computeALE(Experiments(find(inFoci1)),printName1,job1(1).col, project)
                 
                se_TaskInference(inFoci2,printName2,job2(1).col,Experiments,job2, project);
                se_computeALE(Experiments(find(inFoci2)),printName2,job2(1).col, project)
                
                try; se_TaskInferenceDuo([inFoci1; inFoci2],{printName1; printName2},[job1(1).col; job2(1).col],Experiments,all(all([job1(1).FilterIn; job1(1).FilterOut]== [job2(1).FilterIn; job2(1).FilterOut])), project); end

                dFoci = (inFoci1>0 & inFoci2>0);
                inFoci1(dFoci) = 0;
                inFoci2(dFoci) = 0;
                try
                    cols = [job1(1).col; job2(1).col];
                catch
                    cols = [col(cluster1,:); col(cluster2,:);]
                end
                se_computeContrasts(Experiments(inFoci1>0), Experiments(inFoci2>0), printName1, printName2,cols, project)
                
            end
        end
        
        
        [status,message,messageid] = mkdir(fullfile(pwd,'MACM',project,'Specifics'));
        [status,message,messageid] = mkdir(fullfile(pwd,'MACM',project,'Specifics','Images'));
        
        for cluster = 1:size(ROIs,1)
            
            printName = spm_str_manip(deblank(ROIs(cluster,:)),'rt');
            fil = dir(fullfile(pwd,'MACM',project,'Results',[printName '*.nii']));
            Vi = spm_vol(fullfile(pwd,'MACM',project,'Results',fil(1).name));
            dat = spm_read_vols(Vi);
            
            for i=1:numel(dieNamen)
                if woIstWas(i,1) == cluster
                    dat = min(dat,spm_read_vols(spm_vol(dieNamen{i})));
                elseif woIstWas(i,2) == cluster
                    dat = min(dat,-1*spm_read_vols(spm_vol(dieNamen{i})));
                end
            end
            
            dat = dat.*(dat>0);
            
            ind = find(dat);
            [X Y Z] = ind2sub(Vi.dim,ind); z = dat(ind);
            A = spm_clusters([X Y Z]'); Q = [];
            for i=1:max(A)
                if sum(A==i)>50
                    Q = [Q find(A==i)];
                end
            end
            dat = zeros(size(dat));
            dat(ind(Q)) = z(Q);
            
            Vi.fname  = fullfile(pwd,'MACM',project,'Specifics',[printName '.nii']);
            Vi = rmfield(Vi,'pinfo');
            Vi = spm_write_vol(Vi,dat);
            
            se_render_imageCol(Vi.fname,0,0,col(cluster,:))
            print('-dpng',fullfile(pwd,'MACM',project,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
            ImageCut(fullfile(pwd,'MACM',project,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']),'X');
            delete(fullfile(pwd,'MACM',project,'Specifics','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
        end
        
        dat = Inf;
        for cluster = 1:size(ROIs,1)
            printName = spm_str_manip(deblank(ROIs(cluster1,:)),'rt');
            fil = dir(fullfile(pwd,'MACM',project,'Results',[printName '*.nii']));
            Vi = spm_vol(fullfile(pwd,'MACM',project,'Results',fil(1).name));
            dat = min(dat,spm_read_vols(Vi));
        end
        
        Vi.fname  = fullfile(pwd,'MACM',project,'Conjunctions',['All.nii']);
        Vi = rmfield(Vi,'pinfo');
        Vi = spm_write_vol(Vi,dat);
        
        se_render_imageCol(Vi.fname,0,0,col(cluster,:))
        print('-dpng',fullfile(pwd,'MACM',project,'Conjunctions','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
        ImageCut(fullfile(pwd,'MACM',project,'Conjunctions','Images',[spm_str_manip(Vi.fname,'rt') '.png']),'X');
        delete(fullfile(pwd,'MACM',project,'Conjunctions','Images',[spm_str_manip(Vi.fname,'rt') '.png']))
        
        
        se_SpecifyJob('draw')
        
        
        
        
    case 'sale'
        ROIs = se_select(Inf,'vois','Select mask-images or VOI-definition matfiles');
        
        project = spm_input('Project name',1,'s','');
        
        load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
        load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))
        load(fullfile(pwd,'BrainMapData','Tasks.mat'))
        for i=1:size(ROIs,1)
            ROInow = deblank(ROIs(i,:));
            if ~strcmpi(ROInow(end-2:end),'mat')
                job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',60,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
                job(1).VOIs{1} = ROInow;
            else
                load(ROInow)
            end
            
            if ~isfield(job,'col'); job(1).col = NaN; end
            inFoci = se_parseJob(job, XYZ2EXP, AllBD);
            printName = [spm_str_manip(ROInow,'rt')];
            se_makeWorkspace(Experiments(find(inFoci)),printName, project);
            fprintf(1,'%s\n',[printName ': ' int2str(numel(find(inFoci))) ' Experiments'])
            se_TaskInference(inFoci,printName,job(1).col,Experiments,job, project);
            se_computeALE(Experiments(find(inFoci)),printName,job(1).col, project);
%            se_ClusterContribution(Experiments(find(inFoci)),printName, project);
            se_computeSALE2(Experiments(find(inFoci)),printName,job(1).col, project);
%            se_computeSALE(Experiments,printName,find(inFoci), job(1).col, project);
        end
        
        se_SpecifyJob('draw')
end

