function se_SpecifyVOIs(varargin)

global job con AllBD AllPC
if (nargin==0),
    Action = 'draw';
    if ~isdir('VOIs')
        mkdir('VOIs')
    end
    load(fullfile(pwd,'BrainMapData','Tasks.mat'))
    
    job = struct('VOIs',cell(2,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)),'col',NaN);
    con.x = 0;
else,
    Action = varargin{1};
end

switch lower(Action),
    
    case 'draw'
        spm_figure('Clear','Graphics');
        spm('CreateIntWin','on');
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .95 .6 .04],'string',{['Tolerated Distance from VOI: ' num2str(job(1).Distance) ' mm']},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''distance'')','foregroundcolor','k');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .9 .6 .04],'string',{['Number Foci per VOI: ' num2str(job(1).Number)]},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''Number'')','foregroundcolor','k');
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.75 .95 .2 .04],'string',{'Specify color'},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''color'')','foregroundcolor','k');
        
        axes('parent',fg,'position',[0.75 .9 .2 .04]);
        if any(isnan(job(1).col))
            cmap = load('Split.mat');
            image(65:128); colormap(cmap.split)
        else
            image(cat(3,ones(1,64)*job(1).col(1),ones(1,64)*job(1).col(2),ones(1,64)*job(1).col(3)))
        end
        axis off; rectangle('Position',[0.5 0.5 64 1])
        
        if any(job(1).FilterIn>0) | any(job(1).FilterOut>0)
            uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .85 .8 .04],'string',{'Specific behavioural domain filter'},...
                'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''filter'')','foregroundcolor','g');
        else
            uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .85 .8 .04],'string',{'Specific behavioural domain filter'},...
                'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''filter'')','foregroundcolor','k');
        end
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.05 .75 .35 .04],'string','Select VOI(s)',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''files1'')','foregroundcolor','k','FontSize',14);
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.425 .75 .35 .04],'string','Select Coordinate(s)',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''coord1'')','foregroundcolor','k','FontSize',14);
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .605 .9 .14],'string',job(1).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        con.f1 = uicontrol(fg,'Style','popupmenu','Units','normalized','Position',[0.8 .75 .1 .04],...
            'String',char('AND','OR'),'Value',job(1).within,'FontSize',14,'callback','global con job; job(1).within = get(con.f1,''value'');');
        
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.05 .46 .35 .04],'string','Select VOI(s)',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''files2'')','foregroundcolor','k','FontSize',14);
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.425 .46 .35 .04],'string','Select coordinate(s)',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''coord2'')','foregroundcolor','k','FontSize',14);
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .315 .9 .14],'string',job(2).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        con.f2 = uicontrol(fg,'Style','popupmenu','Units','normalized','Position',[0.8 .46 .1 .04],...
            'String',char('AND','OR'),'Value',job(2).within,'FontSize',14,'callback','global con job; job(2).within = get(con.f2,''value'');');
        
        con.f3 = uicontrol(fg,'Style','popupmenu','Units','normalized','Position',[0.1 .47 .2 .1],...
            'String',char('AND','OR'),'Value',job(1).between,'FontSize',16,'callback','global con job; job(1).between = get(con.f3,''value'');');
        
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.05 .042 .4 .04],'string','Save VOI definition',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''save'')','foregroundcolor','k','FontSize',14);
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.53 .04 .4 .04],'string','Load VOI definition',...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''load'')','foregroundcolor','k','FontSize',14);
        
        
    case 'color'
        if spm_input('Which colours?','!+1','b',{'Red-White','Custom'},[0 1],1)
            job(1).col = uisetcolor([1 0 0],'Colour of blob set');
        else
            job(1).col = NaN;
        end
        se_SpecifyVOIs('draw')
        
    case 'filter'
        spm_figure('Clear','Graphics');
        fg = spm_figure('GetWin','Graphics');
        spm('CreateIntWin','on');
        try; con = rmfield(con,'BD'); end; try; con = rmfield(con,'PC'); end
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .91 .75 .08],...
            'string',{'Multiple  domains may be selected; Selections within a column combine as OR, columns  as AND'} ,'FontSize',14,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','BackgroundColor',[1 1 1]);
        
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.85 .94 .1 .05],'callback','se_SpecifyVOIs(''filtered'')',...
            'string',{'OK'} ,'FontSize',14,'horizontalalignment','center','fontweight','bold','foregroundcolor','k','BackgroundColor',[0 1 0]);
        
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .88 .4 .05],...
            'string',{'Limit to'} ,'FontSize',14,...
            'horizontalalignment','left','fontweight','bold','foregroundcolor','g','BackgroundColor',[1 1 1]);
        for i=1:47
            con.BD(i) = uicontrol(fg,'Style','checkbox','Units','normalized','Position',[0.05 .905-.019*i .025 .019],'value',job(1).FilterIn(i));
            uicontrol(fg,'Style','text','Units','normalized','Position',[0.09 .905-.019*i .4 .019],'String',AllBD(i).Name,'HorizontalAlignment','left','BackgroundColor',[1 1 1]);
        end
        
        uicontrol(fg,'style','text','units','normalized','position',[0.55 .88 .4 .05],...
            'string',{'Exclude'} ,'FontSize',14,...
            'horizontalalignment','left','fontweight','bold','foregroundcolor','r','BackgroundColor',[1 1 1]);
        for i=1:47
            con.noBD(i) = uicontrol(fg,'Style','checkbox','Units','normalized','Position',[0.55 .905-.019*i .025 .019],'value',job(1).FilterOut(i));
            uicontrol(fg,'Style','text','Units','normalized','Position',[0.59 .905-.019*i .4 .019],'String',AllBD(i).Name,'HorizontalAlignment','left','BackgroundColor',[1 1 1]);
        end
        
    case 'filtered'
        for i=1:47
            job(1).FilterIn(i)  = get(con.BD(i),'value');
            job(1).FilterOut(i) = get(con.noBD(i),'value');
        end
        se_SpecifyVOIs('draw')
        
        
    case 'save'
        job(1).within = get(con.f1,'value');
        job(2).within = get(con.f2,'value');
        job(1).between = get(con.f3,'value');
        [file pfad] = uiputfile({'*.mat','MAT-files (*.mat)'},'Save VOI definition as',fullfile(pwd,'VOIs'));
        save(fullfile(pfad, file),'job');
        
    case 'load'
        fg = spm_figure('GetWin','Graphics');
        load(spm_select(Inf,'mat','Select VOI definition file'));
        if ~isfield(job,'col'); job(1).col = NaN; end
        se_SpecifyVOIs('draw')
        
    case 'files1'
        job(1).VOIs = {spm_select(Inf,'image','Select VOI files')};
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .605 .9 .14],'string',job(1).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        
    case 'coord1'
        job(1).VOIs = {int2str(spm_input(['Enter: XYZ; XYZ'],'+0','r','',[Inf 3]))};
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .605 .9 .14],'string',job(1).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        
        
    case 'files2'
        job(2).VOIs = {spm_select(Inf,'image','Select VOI files')};
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .315 .9 .14],'string',job(2).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        
    case 'coord2'
        job(2).VOIs = {int2str(spm_input(['Enter: XYZ; XYZ'],'+0','r','',[Inf 3]))};
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','text','units','normalized','position',[0.05 .315 .9 .14],'string',job(2).VOIs,'FontSize',12,...
            'horizontalalignment','center','fontweight','bold','foregroundcolor','k','HorizontalAlignment','left','BackgroundColor',[.9 .9 .9]);
        
        
    case 'distance'
        [job.Distance] = deal(spm_input('Tolerated Distance',1,'r',job(1).Distance));
        [job.Number] = deal(0);
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .95 .6 .04],'string',{['Tolerated Distance from VOI: ' num2str(job(1).Distance) ' mm']},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''distance'')','foregroundcolor','r');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .9 .6 .04],'string',{['Number Foci per VOI: ' num2str(job(1).Number)]},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''Number'')','foregroundcolor','k');
        
    case 'number'
        [job.Number] = deal(spm_input('Number of Foci',1,'r',job(1).Number));
        [job.Distance] = deal(0);
        fg = spm_figure('GetWin','Graphics');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .95 .6 .04],'string',{['Tolerated Distance from VOI: ' num2str(job(1).Distance) ' mm']},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''distance'')','foregroundcolor','k');
        uicontrol(fg,'style','pushbutton','units','normalized','position',[0.1 .9 .6 .04],'string',{['Number Foci per VOI: ' num2str(job(1).Number)]},...
            'horizontalalignment','center','fontweight','bold','callback','se_SpecifyVOIs(''Number'')','foregroundcolor','r');
        
end

