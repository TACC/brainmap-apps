function se_TaskInferenceDuo(dQ,printName,col,Experiments,wasSameFilter, project)

load(fullfile(pwd,'BrainMapData','SpecificTasks.mat'))


    BDnames = {AllBD.Name}';
    PCnames = {AllPC.Name}';

    
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'BDPC-Contrasts'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'BDPC-Conjunctions'));

dQ(:,strcmp({Experiments.Type},'De-Activations')) = 0;

try; delete(99); end


figure(99), clf
set(gcf,'Position',get(0,'ScreenSize'))





Q = dQ(1,:);
for i=1:numel(AllBD)
    PActITask = sum(Q(AllBD(i).Experiments))/size([Experiments(AllBD(i).Experiments).XYZmm],2);
    PAct1      = sum(Q)/size([Experiments.XYZmm],2);
    PTask     = AllBD(i).Available/sum([AllBD.Available]);
    ForInfBD(i,:)   = [PActITask sum(Q(AllBD(i).Experiments)) size([Experiments(AllBD(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]))];
    RevInfBD(i,1) = (PActITask*PTask)/PAct1;
    QQ = zeros(1,numel(Experiments)); QQ(AllBD(i).Experiments) = 1;
    if sum(Q(AllBD(i).Experiments))>4 & ForInfBD(i,2)>ForInfBD(i,3)
        [table,chi2,BDp1(i,1)] = crosstab(Q,QQ);
        BDp1(i,2) = 1-binocdf(sum(Q(AllBD(i).Experiments)),size([Experiments(AllBD(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
    else, BDp1(i,1:2) = [1 1];
    end
end
RevInfBD1 = RevInfBD/sum(RevInfBD); ForInfBD1 = ForInfBD;

for i=1:numel(AllPC)
    PActITask = sum(Q(AllPC(i).Experiments))/size([Experiments(AllPC(i).Experiments).XYZmm],2);
    PAct1      = sum(Q)/size([Experiments.XYZmm],2);
    PTask     = AllPC(i).Available/sum([AllPC.Available]);
    ForInfPC(i,:)   = [PActITask sum(Q(AllPC(i).Experiments)) size([Experiments(AllPC(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]))];
    RevInfPC(i,1) = (PActITask*PTask)/PAct1;
    QQ = zeros(1,numel(Experiments)); QQ(AllPC(i).Experiments) = 1;
    if sum(Q(AllPC(i).Experiments))>4 & ForInfPC(i,2)>ForInfPC(i,3)
        [table,chi2,PCp1(i,1)] = crosstab(Q,QQ);
        PCp1(i,2) = 1-binocdf(sum(Q(AllPC(i).Experiments)),size([Experiments(AllPC(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
    else, PCp1(i,1:2) = [1 1];
    end
end
RevInfPC1 = RevInfPC/sum(RevInfPC); ForInfPC1 = ForInfPC;


Q = dQ(2,:);
for i=1:numel(AllBD)
    PActITask = sum(Q(AllBD(i).Experiments))/size([Experiments(AllBD(i).Experiments).XYZmm],2);
    PAct2      = sum(Q)/size([Experiments.XYZmm],2);
    PTask     = AllBD(i).Available/sum([AllBD.Available]);
    ForInfBD(i,:)   = [PActITask sum(Q(AllBD(i).Experiments)) size([Experiments(AllBD(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]))];
    RevInfBD(i,1) = (PActITask*PTask)/PAct2;
    QQ = zeros(1,numel(Experiments)); QQ(AllBD(i).Experiments) = 1;
    if sum(Q(AllBD(i).Experiments))>4 & ForInfBD(i,2)>ForInfBD(i,3)
        [table,chi2,BDp2(i,1)] = crosstab(Q,QQ);
        BDp2(i,2) = 1-binocdf(sum(Q(AllBD(i).Experiments)),size([Experiments(AllBD(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
    else, BDp2(i,1:2) = [1 1];
    end
end
RevInfBD2 = RevInfBD/sum(RevInfBD); ForInfBD2 = ForInfBD;

for i=1:numel(AllPC)
    PActITask = sum(Q(AllPC(i).Experiments))/size([Experiments(AllPC(i).Experiments).XYZmm],2);
    PAct2      = sum(Q)/size([Experiments.XYZmm],2);
    PTask     = AllPC(i).Available/sum([AllPC.Available]);
    ForInfPC(i,:)   = [PActITask sum(Q(AllPC(i).Experiments)) size([Experiments(AllPC(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]))];
    RevInfPC(i,1) = (PActITask*PTask)/PAct2;
    QQ = zeros(1,numel(Experiments)); QQ(AllPC(i).Experiments) = 1;
    if sum(Q(AllPC(i).Experiments))>4 & ForInfPC(i,2)>ForInfPC(i,3)
        [table,chi2,PCp2(i,1)] = crosstab(Q,QQ);
        PCp2(i,2) = 1-binocdf(sum(Q(AllPC(i).Experiments)),size([Experiments(AllPC(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
    else, PCp2(i,1:2) = [1 1];
    end
end
RevInfPC2 = RevInfPC/sum(RevInfPC); ForInfPC2 = ForInfPC;



xQ = (max(BDp1(:,2),BDp2(:,2)))<0.05; 
Data = [ForInfBD1(xQ,1)./PAct1 ForInfBD2(xQ,1)./PAct2];
Names= BDnames(xQ);
figure(99), subplot(2,2,1),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Activation | Domain)'); xlabel('Probability likelihood ratio');
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = (max(PCp1(:,2),PCp2(:,2)))<0.05; % (0.05/sum(ForInfPC(:,1)>0));
Data = [ForInfPC1(xQ,1)./PAct1 ForInfPC2(xQ,1)./PAct2];
Names= PCnames(xQ);
figure(99), subplot(2,2,3),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Activation | Task)'); xlabel('Probability likelihood ratio');
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end




xQ = (max(BDp1(:,1),BDp2(:,1)))<0.05; 
Data = [RevInfBD1(xQ) RevInfBD2(xQ)];
Names= BDnames(xQ);
figure(99), subplot(2,2,2),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Domain | Activation)'); 
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = (max(PCp1(:,1),PCp2(:,1)))<0.05; 
Data = [RevInfPC1(xQ) RevInfPC2(xQ)];
Names= PCnames(xQ);
figure(99), subplot(2,2,4),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Task | Activation)'); 
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end


print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Conjunctions',[[printName{1} '_AND_' printName{2}] '_uc05.png']))
delete(99);








xQ = (max(BDp1(:,2),BDp2(:,2)))<(0.05/sum(ForInfBD(:,1)>0));
Data = [ForInfBD1(xQ,1)./PAct1 ForInfBD2(xQ,1)./PAct2];
Names= BDnames(xQ);
figure(99), subplot(2,2,1),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Activation | Domain)'); xlabel('Probability likelihood ratio');
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = (max(PCp1(:,2),PCp2(:,2)))<(0.05/sum(ForInfPC(:,1)>0));
Data = [ForInfPC1(xQ,1)./PAct1 ForInfPC2(xQ,1)./PAct2];
Names= PCnames(xQ);
figure(99), subplot(2,2,3),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Activation | Task)'); xlabel('Probability likelihood ratio');
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = (max(BDp1(:,1),BDp2(:,1)))<(0.05/sum(ForInfBD(:,1)>0));
Data = [RevInfBD1(xQ) RevInfBD2(xQ)];
Names= BDnames(xQ);
figure(99), subplot(2,2,2),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Activation | Domain)'); 
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = (max(PCp1(:,1),PCp2(:,1)))<(0.05/sum(ForInfPC(:,1)>0));
Data = [RevInfPC1(xQ) RevInfPC2(xQ)];
Names= PCnames(xQ);
figure(99), subplot(2,2,4),
if sum(xQ)>0
    [B II] = sort(mean(Data,2),'descend'); barh([Data(II,:)]), colormap([col]); axis tight;
    set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',[Names(II)],'YLim',floor(get(gca,'YLim'))+[0 1]); title('P(Task | Activation)'); 
else
    text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end


print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Conjunctions',[[printName{1} '_AND_' printName{2}] '_Bonf05.png']))
delete(99);













clear ForInfBD ForInfPC RevInfBD RevInfPC 

dQ(:,sum(dQ)>1) = 0;

use = sum(dQ)>0;

for i=1:numel(AllBD)
  AllBD(i).Experiments = AllBD(i).Experiments(use(AllBD(i).Experiments)>0);
  AllBD(i).Available =  numel(AllBD(i).Experiments);
end

for i=1:numel(AllPC)
  AllPC(i).Experiments = AllPC(i).Experiments(use(AllPC(i).Experiments)>0);
  AllPC(i).Available =  numel(AllPC(i).Experiments);
end


figure(99), 
set(gcf,'Position',get(0,'ScreenSize'))


if wasSameFilter
  da      = find([AllBD.Available]>4);
  nQ      = sum(sum(dQ)>0);
  ratio   = sum(dQ')/sum(dQ(:));
  wo      = find(sum(dQ)>0);
  repeats = 1000;
  
  for xi=1:numel(da)
    i = da(xi);
    
    PTask = AllBD(i).Available/sum([AllBD.Available]);
    
    for im = 1:size(dQ,1)
      ForInfBD(xi,im) = sum(dQ(im,AllBD(i).Experiments))/AllBD(i).Available;
      RevInfBD(xi,im) = (ForInfBD(xi,im) * PTask ) / ratio(im);
    end
    
    FA = 0;
    RA = [0 0];
    xQ = dQ;
    xForInfBD = nan(repeats+1,size(dQ,1)); xForInfBD(repeats+1,:) = ForInfBD(xi,:);
    xRevInfBD = nan(repeats+1,size(dQ,1)); xRevInfBD(repeats+1,:) = RevInfBD(xi,:);
    
    for ri=1:repeats
      xQ(:,wo) = dQ(:,wo(randperm(nQ)));
      for im = 1:size(dQ,1)
        xForInfBD(ri,im) = sum(xQ(im,AllBD(i).Experiments))/AllBD(i).Available;
        xRevInfBD(ri,im) = (xForInfBD(ri,im) * PTask ) / ratio(im);
      end
    end
    
    for im = 1:size(dQ,1)
      pForInfBD(xi,im) = sum(xForInfBD(:,im)>ForInfBD(xi,im));
    end
    
    
    QQ = (sparse(1,AllBD(i).Experiments,1,1,numel(Experiments)));
    [table,chi2,BDp(xi)] = crosstab(dQ(1,use),QQ(use));
  end
  
  pForInfBD = (pForInfBD/repeats)+eps;
  
  BDnames = {AllBD(da).Name}';
  PCnames = {AllPC(da).Name}';
  
  xQ = min(pForInfBD,[],2)<0.05;  % & [AllBD(da).Available]'>9;
  if sum(xQ)>0
    Data = ForInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,1), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Domain)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
  else
    figure(99), subplot(2,2,1), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  end
  
  xQ = BDp<0.05;
  if sum(xQ)>0
    Data = RevInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,2), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Domain | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
  else
    figure(99), subplot(2,2,2), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  end
 
else
  figure(99), subplot(2,2,2), cla
  text(.5,.5,'VOIs were filtered for different BDs','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  figure(99), subplot(2,2,1), cla
  text(.5,.5,'VOIs were filtered for different BDs','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end












da      = find([AllPC.Available]>4);
nQ      = sum(sum(dQ)>0);
ratio   = sum(dQ')/sum(dQ(:));
wo      = find(sum(dQ)>0);
repeats = 1000;

for xi=1:numel(da)
  i = da(xi);
  
  PTask = AllPC(i).Available/sum([AllPC.Available]);
  
  for im = 1:size(dQ,1)
    ForInfPC(xi,im) = sum(dQ(im,AllPC(i).Experiments))/AllPC(i).Available;
    RevInfPC(xi,im) = (ForInfPC(xi,im) * PTask ) / ratio(im);
  end
  
  FA = 0;
  RA = [0 0];
  xQ = dQ;
  xForInfPC = nan(repeats+1,size(dQ,1)); xForInfPC(repeats+1,:) = ForInfPC(xi,:);
  xRevInfPC = nan(repeats+1,size(dQ,1)); xRevInfPC(repeats+1,:) = RevInfPC(xi,:);
  
  for ri=1:repeats
    xQ(:,wo) = dQ(:,wo(randperm(nQ)));
    for im = 1:size(dQ,1)
      xForInfPC(ri,im) = sum(xQ(im,AllPC(i).Experiments))/AllPC(i).Available;
      xRevInfPC(ri,im) = (xForInfPC(ri,im) * PTask ) / ratio(im);
    end
  end
  
  for im = 1:size(dQ,1)
    pForInfPC(xi,im) = sum(xForInfPC(:,im)>ForInfPC(xi,im));
  end
  
  
  QQ = (sparse(1,AllPC(i).Experiments,1,1,numel(Experiments)));
  [table,chi2,PCp(xi)] = crosstab(dQ(1,use),QQ(use));
end

pForInfPC = (pForInfPC/repeats)+eps;

PCnames = {AllPC(da).Name}';
PCnames = {AllPC(da).Name}';

xQ = min(pForInfPC,[],2)<0.05; % & [AllPC(da).Available]'>9;
if sum(xQ)>0
  Data = ForInfPC(xQ,:);
  Names= PCnames(xQ);
  figure(99), subplot(2,2,3), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Paradigm)');
  colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
  figure(99), subplot(2,2,3), cla
  text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = PCp<0.05;
if sum(xQ)>0
  Data = RevInfPC(xQ,:);
  Names= PCnames(xQ);
  figure(99), subplot(2,2,4), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Paradigm | Activation)');
  colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
  figure(99), subplot(2,2,4), cla
  text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end


print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Contrasts',[[printName{1} '--' printName{2}] '_uc05.png']))
delete(99);






xQ = min(pForInfPC,[],2)<0.01; % & [AllPC(da).Available]'>9;
if sum(xQ)>0
    Data = ForInfPC(xQ,:);
    Names= PCnames(xQ);
    figure(99), subplot(2,2,3), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Paradigm)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,3), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = PCp<0.01;
if sum(xQ)>0
    Data = RevInfPC(xQ,:);
    Names= PCnames(xQ);
    figure(99), subplot(2,2,4), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Paradigm | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,4), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = min(pForInfBD,[],2)<0.01;  % & [AllBD(da).Available]'>9;
if sum(xQ)>0
    Data = ForInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,1), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Domain)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,1), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = BDp<0.01;
if sum(xQ)>0
    Data = RevInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,2), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Domain | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,2), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Contrasts',[[printName{1} '--' printName{2}] '_uc01.png']))
delete(99);








% Hier Bonf Contrast

xQ = min(pForInfPC,[],2)<(0.05/numel(min(pForInfPC,[],2))); % & [AllPC(da).Available]'>9;
if sum(xQ)>0
    Data = ForInfPC(xQ,:);
    Names= PCnames(xQ);
    figure(99), subplot(2,2,3), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Paradigm)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,3), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = PCp<(0.05/numel(PCp));
if sum(xQ)>0
    Data = RevInfPC(xQ,:);
    Names= PCnames(xQ);
    figure(99), subplot(2,2,4), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Paradigm | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,4), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = min(pForInfBD,[],2)<(0.05/numel(min(pForInfBD,[],2)));;  % & [AllBD(da).Available]'>9;
if sum(xQ)>0
    Data = ForInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,1), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Domain)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,1), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = BDp<(0.05/numel(BDp));;
if sum(xQ)>0
    Data = RevInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,2), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Domain | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
    figure(99), subplot(2,2,2), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Contrasts',[[printName{1} '--' printName{2}] '_uc01.png']))
delete(99);












% Hier FDR

clear ForInfBD ForInfPC RevInfBD RevInfPC 

dQ(:,sum(dQ)>1) = 0;

use = sum(dQ)>0;

for i=1:numel(AllBD)
  AllBD(i).Experiments = AllBD(i).Experiments(use(AllBD(i).Experiments)>0);
  AllBD(i).Available =  numel(AllBD(i).Experiments);
end

for i=1:numel(AllPC)
  AllPC(i).Experiments = AllPC(i).Experiments(use(AllPC(i).Experiments)>0);
  AllPC(i).Available =  numel(AllPC(i).Experiments);
end


figure(99)
set(gcf,'Position',get(0,'ScreenSize'))


if wasSameFilter
  da      = find([AllBD.Available]>4);
  nQ      = sum(sum(dQ)>0);
  ratio   = sum(dQ')/sum(dQ(:));
  wo      = find(sum(dQ)>0);
  repeats = 1000;
  
  for xi=1:numel(da)
    i = da(xi);
    
    PTask = AllBD(i).Available/sum([AllBD.Available]);
    
    for im = 1:size(dQ,1)
      ForInfBD(xi,im) = sum(dQ(im,AllBD(i).Experiments))/AllBD(i).Available;
      RevInfBD(xi,im) = (ForInfBD(xi,im) * PTask ) / ratio(im);
    end
    
    FA = 0;
    RA = [0 0];
    xQ = dQ;
    xForInfBD = nan(repeats+1,size(dQ,1)); xForInfBD(repeats+1,:) = ForInfBD(xi,:);
    xRevInfBD = nan(repeats+1,size(dQ,1)); xRevInfBD(repeats+1,:) = RevInfBD(xi,:);
    
    for ri=1:repeats
      xQ(:,wo) = dQ(:,wo(randperm(nQ)));
      for im = 1:size(dQ,1)
        xForInfBD(ri,im) = sum(xQ(im,AllBD(i).Experiments))/AllBD(i).Available;
        xRevInfBD(ri,im) = (xForInfBD(ri,im) * PTask ) / ratio(im);
      end
    end
    
    for im = 1:size(dQ,1)
      pForInfBD(xi,im) = sum(xForInfBD(:,im)>ForInfBD(xi,im));
    end
    
    
    QQ = (sparse(1,AllBD(i).Experiments,1,1,numel(Experiments)));
    [table,chi2,BDp(xi)] = crosstab(dQ(1,use),QQ(use));
  end
  
  pForInfBD = (pForInfBD/repeats)+eps;
  
  BDnames = {AllBD(da).Name}';
  PCnames = {AllPC(da).Name}';
  
  
  xQ = min(pForInfBD,[],2)<=min((0.05/size(pForInfBD,1)),spm_uc_FDR(0.05,1,'P',1,sort(min(pForInfBD,[],2),'ascend'),[]));  % & [AllBD(da).Available]'>9;
  if sum(xQ)>0
    Data = ForInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,1), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Domain)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
  else
    figure(99), subplot(2,2,1), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  end
  
  xQ = BDp<= min((0.05/numel(BDp)),spm_uc_FDR(0.05,1,'P',1,sort(BDp,'ascend')',[]));
  if sum(xQ)>0
    Data = RevInfBD(xQ,:);
    Names= BDnames(xQ);
    figure(99), subplot(2,2,2), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Domain | Activation)');
    colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
  else
    figure(99), subplot(2,2,2), cla
    text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  end
  
else
  figure(99), subplot(2,2,2), cla
  text(.5,.5,'VOIs were filtered for different BDs','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
  figure(99), subplot(2,2,1), cla
  text(.5,.5,'VOIs were filtered for different BDs','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end




da      = find([AllPC.Available]>4);
nQ      = sum(sum(dQ)>0);
ratio   = sum(dQ')/sum(dQ(:));
wo      = find(sum(dQ)>0);
repeats = 1000;

for xi=1:numel(da)
  i = da(xi);
  
  PTask = AllPC(i).Available/sum([AllPC.Available]);
  
  for im = 1:size(dQ,1)
    ForInfPC(xi,im) = sum(dQ(im,AllPC(i).Experiments))/AllPC(i).Available;
    RevInfPC(xi,im) = (ForInfPC(xi,im) * PTask ) / ratio(im);
  end
  
  FA = 0;
  RA = [0 0];
  xQ = dQ;
  xForInfPC = nan(repeats+1,size(dQ,1)); xForInfPC(repeats+1,:) = ForInfPC(xi,:);
  xRevInfPC = nan(repeats+1,size(dQ,1)); xRevInfPC(repeats+1,:) = RevInfPC(xi,:);
  
  for ri=1:repeats
    xQ(:,wo) = dQ(:,wo(randperm(nQ)));
    for im = 1:size(dQ,1)
      xForInfPC(ri,im) = sum(xQ(im,AllPC(i).Experiments))/AllPC(i).Available;
      xRevInfPC(ri,im) = (xForInfPC(ri,im) * PTask ) / ratio(im);
    end
  end
  
  for im = 1:size(dQ,1)
    pForInfPC(xi,im) = sum(xForInfPC(:,im)>ForInfPC(xi,im));
  end
  
  
  QQ = (sparse(1,AllPC(i).Experiments,1,1,numel(Experiments)));
  [table,chi2,PCp(xi)] = crosstab(dQ(1,use),QQ(use));
end

pForInfPC = (pForInfPC/repeats)+eps;

PCnames = {AllPC(da).Name}';
PCnames = {AllPC(da).Name}';

xQ = min(pForInfPC,[],2)<= min((0.05/size(pForInfPC,1)),spm_uc_FDR(0.05,1,'P',1,sort(min(pForInfPC,[],2),'ascend'),[]));  % & [AllBD(da).Available]'>9;
if sum(xQ)>0
  Data = ForInfPC(xQ,:);
  Names= PCnames(xQ);
  figure(99), subplot(2,2,3), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh([Data(II,:); ratio],'stacked'), set(gca,'YDir','reverse','YTick',1:sum(xQ)+1,'YTickLabel',[Names(II); 'Baserate']); title('P(Activation | Paradigm)');
  colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
  figure(99), subplot(2,2,3), cla
  text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end

xQ = PCp<= min((0.05/numel(PCp)),spm_uc_FDR(0.05,1,'P',1,sort(PCp,'ascend')',[]));
if sum(xQ)>0
  Data = RevInfPC(xQ,:);
  Names= PCnames(xQ);
  figure(99), subplot(2,2,4), [B II] = sort(Data(:,1)./Data(:,2),'descend'); barh(Data(II,:)), set(gca,'YDir','reverse','YTick',1:sum(xQ),'YTickLabel',Names(II)); title('P(Paradigm | Activation)');
  colormap(col); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
else
  figure(99), subplot(2,2,4), cla
  text(.5,.5,'No significant differences','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
end


print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC-Contrasts',[[printName{1} '--' printName{2}] '_FDR05.png']))



