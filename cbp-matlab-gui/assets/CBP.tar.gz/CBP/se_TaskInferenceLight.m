function [BDprofile, PCprofile] = se_TaskInferenceLight(Q,printName,col,Experiments,job, project)

if isnan(col)
    col = [.75 .75 .75];
end

if nargin<5
    project = '';
end

try; delete(99); end


[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'BDPC'));

Q(strcmp({Experiments.Type},'De-Activations')) = 0;

if numel(project)>0
    figure(99), clf
    set(gcf,'Position',get(0,'ScreenSize'))
end


load(fullfile(pwd,'BrainMapData','SpecificTasks.mat'))

if ~any(any(job(1).FilterIn)) & ~any(any(job(1).FilterOut))
    for i=1:numel(AllBD)
        PActITask = sum(Q(AllBD(i).Experiments))/size([Experiments(AllBD(i).Experiments).XYZmm],2);
        PAct      = sum(Q)/size([Experiments.XYZmm],2);
        PTask     = AllBD(i).Available/sum([AllBD.Available]);
        
        ForInfBD(i,1) = PActITask;
        ForInfBD(i,2)   = sum(Q(AllBD(i).Experiments));
        ForInfBD(i,3)   = size([Experiments(AllBD(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]));
        RevInfBD(i,1) = (PActITask*PTask)/PAct;
        
        QQ = zeros(1,numel(Experiments));
        QQ(AllBD(i).Experiments) = 1;
        if sum(Q(AllBD(i).Experiments))>4 & ForInfBD(i,2)>ForInfBD(i,3)
            [table,chi2,BDp(i,1)] = crosstab(Q,QQ);
            BDp(i,2) = 1-binocdf(sum(Q(AllBD(i).Experiments)),size([Experiments(AllBD(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
        else
            BDp(i,1:2) = [1 1];
        end
        
        
    end
    RevInfBD = RevInfBD/sum(RevInfBD);
end



for i=1:numel(AllPC)
    PActITask = sum(Q(AllPC(i).Experiments))/size([Experiments(AllPC(i).Experiments).XYZmm],2);
    PAct      = sum(Q)/size([Experiments.XYZmm],2);
    PTask     = AllPC(i).Available/sum([AllPC.Available]);
    
    ForInfPC(i,1) = PActITask;
    ForInfPC(i,2)   = sum(Q(AllPC(i).Experiments));
    ForInfPC(i,3)   = size([Experiments(AllPC(i).Experiments).XYZmm],2)*sum(Q)/sum(sum([Experiments.Peaks]));
    RevInfPC(i,1) = (PActITask*PTask)/PAct;
    
    QQ = zeros(1,numel(Experiments));
    QQ(AllPC(i).Experiments) = 1;
    if sum(Q(AllPC(i).Experiments))>4
        [table,chi2,PCp(i,1)] = crosstab(Q,QQ);
        PCp(i,2) = 1-binocdf(sum(Q(AllPC(i).Experiments)),size([Experiments(AllPC(i).Experiments).XYZmm],2),sum(Q)/sum(sum([Experiments.Peaks])));
    else
        PCp(i,1:2) = [1 1];
    end
    
end
RevInfPC = RevInfPC/sum(RevInfPC);

BDprofile = [ForInfBD(:,1)./PAct RevInfBD spm_invNcdf(1-BDp(:,2))];
PCprofile = [ForInfPC(:,1)./PAct RevInfPC spm_invNcdf(1-PCp(:,2))];







if numel(project)>0
        
    BDnames= {AllBD.Name};
    PCnames= {AllPC.Name};
        
    for run =1:2
        
        if ~any(job(1).FilterIn)  & ~any(any(job(1).FilterOut))
            
            % BDf
            if run==1
                xQ = BDp(:,2)<0.05;
            elseif run==2
                xQ = BDp(:,2)<= max((0.05/sum(ForInfBD(:,1)>0)),spm_uc_FDR(0.05,1,'P',1,sort(BDp(:,2),'ascend'),[]));
            end
            
            Data = ForInfBD(xQ,1)./PAct;
            Names= BDnames(xQ);
            figure(99), subplot(2,2,1),
            if sum(xQ)>0
                [B II] = sort(Data,'descend');  Names = Names(II); barh(Data(II)), set(gca,'YDir','reverse','YTick',[]); title('P(Activation | Domain)');
                for i=1:sum(xQ); text(max(Data)*.02,i,Names{i},'horizontalAlignment','left','VerticalAlignment','middle'); end
                colormap([col]); axis tight; xlabel('Likelihood ratio');
                set(gca,'YLim',floor(get(gca,'YLim'))+[0 1]);
            else
                text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
            end
            
            %BDr
            if run==1
                xQ = BDp(:,1)<0.05;
            elseif run==2
                xQ = BDp(:,1)<= max((0.05/sum(RevInfBD(:,1)>0)),spm_uc_FDR(0.05,1,'P',1,sort(BDp(:,1),'ascend'),[]));
            end
            Data = RevInfBD(xQ);
            Names= PCnames(xQ);
            figure(99), subplot(2,2,2),
            if sum(xQ)>0
                [B II] = sort(Data','descend');  Names = Names(II); barh(Data(II)), set(gca,'YDir','reverse','YTick',[]); title('P(Domain | Activation)');
                for i=1:sum(xQ); text(max(Data)*.02,i,Names{i},'horizontalAlignment','left','VerticalAlignment','middle'); end
                colormap([col]); axis tight; xlabel('Probability'); set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
            else
                text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
            end
            
            
        else
            figure(99), subplot(2,2,2), cla
            text(.5,.5,'Data was filtered for BD','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
            figure(99), subplot(2,2,1), cla
            text(.5,.5,'Data was filtered for BD','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
            
        end
        
        
        % PCf
        if run==1
            xQ = PCp(:,2)<0.05;
        elseif run==2
            xQ = PCp(:,2)<= min((0.05/sum(ForInfPC(:,1)>0)),spm_uc_FDR(0.05,1,'P',1,sort(PCp(:,2),'ascend'),[]));
        end
        
        Data = ForInfPC(xQ,1)./PAct;
        Names= PCxnames(xQ);
        figure(99), subplot(2,2,3),
        if sum(xQ)>0
            [B II] = sort(Data,'descend'); Names = Names(II); barh(Data(II)), set(gca,'YDir','reverse','YTick',[]); title('P(Activation | Paradigm)');
            for i=1:sum(xQ); text(max(Data)*.02,i,Names{i},'horizontalAlignment','left','VerticalAlignment','middle'); end
            colormap([col]); axis tight; xlabel('Likelihood ratio')
            set(gca,'YLim',floor(get(gca,'YLim'))+[0 1]);
        else
            text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
        end
        
        
        if run==1
            xQ = PCp(:,1)<0.05;
        elseif run==2
            xQ = PCp(:,1)<= min((0.05/sum(RevInfPC(:,1)>0)),spm_uc_FDR(0.05,1,'P',1,sort(PCp(:,1),'ascend'),[]));
        end
        
        Data = RevInfPC(xQ);
        Names= PCxnames(xQ);
        figure(99), subplot(2,2,4),
        if sum(xQ)>0
            [B II] = sort(Data','descend'); Names = Names(II); barh(Data(II)), set(gca,'YDir','reverse','YTick',[]); title('P(Paradigm | Activation)');
            for i=1:sum(xQ); text(max(Data)*.02,i,Names{i},'horizontalAlignment','left','VerticalAlignment','middle'); end
            colormap([col]); axis tight; set(gca,'YLim',floor(get(gca,'YLim'))+[0 1])
        else
            text(.5,.5,'No significant effects','HorizontalAlignment','center','VerticalAlignment','middle'), axis off
        end
        
        
        if run==1
            print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC',[printName '_uc05.png']));
        elseif run==2
            print(gcf,'-dpng',fullfile(pwd,'MACM',project,'BDPC',[printName '_FDR05.png']));
        end
        delete(99);
        
         
    end
end