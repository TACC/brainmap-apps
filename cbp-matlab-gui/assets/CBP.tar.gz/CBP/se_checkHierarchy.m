function [T n index] = se_checkHierarchy(mT,nClust, data, onlyGM)


if numel(nClust) == 1
    nClust = [2 nClust];
end
nClust = nClust-1;

        mT = mT(nClust(1):nClust(2),:);
        
        index = 1:size(mT,2);
        T = MatchClusters(mT);
        n(1) = size(T,2);
        
        ex = []; clc; n(2) = 0; uh = 0;
        for level = size(T,1):-1:2
            for i=unique(T(level,:));
                Q = find(T(level,:)==i);
%                fprintf(1,'%5.3f\n',numel(Q(T(level-1,Q)~=mode(T(level-1,Q))))/numel(Q))
                if 1 % numel(Q(T(level-1,Q)~=mode(T(level-1,Q))))/numel(Q)<.3
                    ex = [ex Q(T(level-1,Q)~=mode(T(level-1,Q)))];
                else
                    n(2) = level; n(10+uh) = i; uh = uh+1;
                end
            end
%            fprintf(1,'\n')
        end
        index(ex) = [];
        T(:,ex)   = [];
        n(3) = size(T,2);
        
        if onlyGM
            GM     = spm_get_data(spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii')),data.VOIxyz(:,index));
            index  = index(GM>.1);
            T     = T(:,GM>.1);
        end
        n(4)   = size(T,2);
  
        
        Q = ones(size(index));
        for clu = 1:size(T,1)
            for i=unique(T(clu,:))
                wo = T(clu,:)==i;
                A = spm_clusters(data.VOIxyz(1:3,index(wo)));
                for aa = 1:max(A)
                    if sum(A==aa)<10
                        Q(wo(A==aa)) = 0;
                    end
                end
            end
        end
        index(Q==0) = [];
        T(:,Q==0)   = [];
        n(5)        = size(T,2);

             
             
             