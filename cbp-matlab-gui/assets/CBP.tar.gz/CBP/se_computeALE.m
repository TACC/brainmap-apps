function se_computeALE(Experiments,study, col, project)



try
    v = zeros(10,1); parfor u=1:10; v(u) = 1; end; useParallel = 1; clear u v
catch
    useParallel = 0;
end


TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));
prior    = spm_read_vols(TEMPLATE)>.1;

if nargin<3
    col = NaN;
end

if nargin<4
    project = '';
end


uc  = 0.001;

[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'ALEvolumes'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'ALEvolumesZ'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'NullDistributions'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'Results'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'ImagesFWE'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'ResultsFWE'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'Images/ALE'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'Images/Foci'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'Foci'));


AnzV     = numel(Experiments);

mB = 1;
for i=1:AnzV; mB = mB*(1-max(Experiments(i).Kernel(:))); end

bin = [0:.0001:(1-mB)+.001];
step  = 1/mean(diff(bin));


if exist(fullfile(pwd,'MACM',project,'Foci',[study '.nii']))~=2
    
    fprintf(1,'%s\n',[study ' - illustrate Foci'])
    xleer      = zeros(TEMPLATE.dim);
    
    for i=1:AnzV
        for ii = 1:Experiments(i).Peaks
            xleer(Experiments(i).XYZ(1,ii),Experiments(i).XYZ(2,ii),Experiments(i).XYZ(3,ii)) = ...
                xleer(Experiments(i).XYZ(1,ii),Experiments(i).XYZ(2,ii),Experiments(i).XYZ(3,ii)) +1;
        end
    end
    
    xleer(~prior) = NaN;
    
    
    Vo       = TEMPLATE;
    Vo.fname = fullfile(pwd,'MACM',project,'Foci',[study '.nii']);
    Vo.dt    = [64 1];
    Vo       = rmfield(Vo,'pinfo');
    Vo       = spm_write_vol(Vo,xleer);
    
    se_render_imageCol(Vo(1).fname,0,0,nan)
    print('-dpng',fullfile(pwd,'MACM',project,'Images','Foci',[spm_str_manip(Vo(1).fname,'rt') '.png']))
    ImageCut(fullfile(pwd,'MACM',project,'Images','Foci',[spm_str_manip(Vo(1).fname,'rt') '.png']),'X');
    delete(fullfile(pwd,'MACM',project,'Images','Foci',[spm_str_manip(Vo(1).fname,'rt') '.png']))
    
end



if exist(fullfile(pwd,'MACM',project,'ALEvolumesZ',[study '.nii']))~=2
    
    fprintf(1,'%s\n',[study ' - computing ALE'])
    
    xleer      = zeros(TEMPLATE.dim+[30 30 30]);
    leerALE    = ones(TEMPLATE.dim);
    Hx         = zeros(AnzV,numel(bin));
    
    for i=1:AnzV
        data   = xleer;
        for ii = 1:Experiments(i).Peaks
            data(Experiments(i).XYZ(1,ii):Experiments(i).XYZ(1,ii)+30,Experiments(i).XYZ(2,ii):Experiments(i).XYZ(2,ii)+30,Experiments(i).XYZ(3,ii):Experiments(i).XYZ(3,ii)+30) = ...
                max(data(Experiments(i).XYZ(1,ii):Experiments(i).XYZ(1,ii)+30,Experiments(i).XYZ(2,ii):Experiments(i).XYZ(2,ii)+30,Experiments(i).XYZ(3,ii):Experiments(i).XYZ(3,ii)+30),Experiments(i).Kernel);
        end
        data    = data(16:end-15,16:end-15,16:end-15);
        Hx(i,:) = hist(data(prior),bin);
        leerALE = leerALE.*(1-data);
    end
    
    leerALE         = 1-leerALE;
    leerALE(~prior) = NaN;
    
    
    Vo       = TEMPLATE;
    Vo.fname = fullfile(pwd,'MACM',project,'ALEvolumes',[ study '.nii']);
    Vo.dt    = [64 1];
    Vo       = rmfield(Vo,'pinfo');
    Vo       = spm_write_vol(Vo,leerALE);
    if any(isnan(col))
        se_render_imageCol(Vo(1).fname,0,0,[1 0 0])
    else
        se_render_imageCol(Vo(1).fname,0,0,col)
    end
    print('-dpng',fullfile(pwd,'MACM',project,'Images','ALE',[study '.png']))
    ImageCut(fullfile(pwd,'MACM',project,'Images','ALE',[study '.png']),'X');
    delete(fullfile(pwd,'MACM',project,'Images','ALE',[study '.png']))
end



if exist(fullfile(pwd,'MACM',project,'ALEvolumesZ',[study '.nii']))~=2
    
    fprintf(1,'%s\n',[study ' - permutation-null PDF'])
    ALE   = Hx(1,:);
    
    for iMap=2:AnzV
        V1 = ALE;
        V2 = Hx(iMap,:);
        
        da1 = find(V1);            da2 = find(V2);
        V1  = V1/sum(V1);          V2  = V2/sum(V2);
        
        ALE = zeros(1,numel(bin));
        for i2 = 1:numel(da2)
            p     = V2(da2(i2))*V1(da1);
            score = 1-(1-bin(da2(i2)))*(1-bin(da1));
            wohin = round(score*step)+1;
            ALE(wohin) = ALE(wohin)+p;
        end
    end
    
    lastUsed = find(ALE>0,1,'last');
    cNULL    = fliplr(cumsum(fliplr(ALE(1:lastUsed))));
    
    save(fullfile(pwd,'MACM',project,'NullDistributions',[ study '.mat']),'ALE','cNULL','lastUsed')
    clear ALE V1 V2 ALEdist
    
    
    
    fprintf(1,'%s\n',[study ' - computing p-values'])
    load(fullfile(pwd,'MACM',project,'NullDistributions',[ study '.mat']))
    Vi  = spm_vol(fullfile(pwd,'MACM',project,'ALEvolumes',[ study '.nii']));
    ALE = leerALE;
    p   = ones(Vi.dim);
    mx = numel(cNULL);
    for z=1:Vi.dim(3)
        [x y] = find(prior(:,:,z)>0 & ALE(:,:,z)>0);
        for i = 1:numel(x)
            indx = min(round(ALE(x(i),y(i),z)*step)+1,mx);
            p(x(i),y(i),z) = cNULL(indx);
        end
    end
    Z = spm_invNcdf(1-p,0,1);
    Z(p<eps) = spm_invNcdf(1-eps,0,1)+(ALE(p<eps)*2);
    
    p(~prior) = NaN;
    Z(~prior) = NaN;
    
    Vo       = Vi;
    Vo.dt    = [64 1];
    Vo       = rmfield(Vo,'pinfo');
    Vo.fname = fullfile(pwd,'MACM',project,'ALEvolumesZ',[ study '.nii']);
    spm_write_vol(Vo,Z);
    
end


nullspace = load(fullfile(pwd,'BrainMapData','permSpace.mat'));
  allBM = nullspace.allBM;
  allXYZ = nullspace.allXYZ;
  anzXYZ = nullspace.anzXYZ;
  indice0 = nullspace.indice0;
  indices = nullspace.indices;


load(fullfile(pwd,'MACM',project,'NullDistributions',[ study '.mat']))

if useParallel == 0
    fprintf(1,'%s\n',[study ' - simulating noise'])
    
    
    toRepeat = 5000;
    try
        load(fullfile(pwd,'MACM',project,'NullDistributions',[study '_clustP.mat']));
        StartRunde = runde;
    catch
        N        = nan(1,toRepeat*50);
        NM       = nan(1,toRepeat);
        NN       = nan(1,toRepeat);
        clusters = 1;
        StartRunde     = 1;
    end
    
    
    
    xleer      = zeros(TEMPLATE.dim+[30 30 30]);
    Vi         = single(nan(AnzV,numel(indices)));
    
    
    
    
    tic
    for runde = StartRunde+1:toRepeat
        
        for i=1:AnzV
            nowXYZ = allXYZ(:,ceil(rand(1,Experiments(i).Peaks)*anzXYZ));
            data   = xleer;
            for ii = 1:Experiments(i).Peaks
                data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30) = ...
                    max(data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30),Experiments(i).Kernel);
            end
            Vi(i,:) = (data(indices));
        end
        
        data  = 1-prod(1-Vi);
        p     = cNULL(round(data*step)+1);
        
        NM(runde) = max(data(:));
        A = spm_clusters(double(allXYZ(1:3,p<uc)));
        
        if isempty(A); Q = 0;
        else;          Q = hist(A,1:max(A));
        end
        
        NN(runde) = max(Q);
        N(clusters+1:clusters+numel(Q)) = Q;
        clusters = clusters+numel(Q);
        if rem(runde,100)==0
            fprintf(1,'%s\n',['Iteration ' int2str(runde) ' reached after ' num2str(toc/60,'%3.2f') ' min']);
            save(fullfile(pwd,'MACM',project,'NullDistributions',[ study '_clustP.mat']),'N','NM','NN','clusters','runde')
        end
    end
    
    N = sort(N(~isnan(N)),'descend');
    cut = N(ceil(numel(N)*.05));
    
    NN = sort(NN(~isnan(NN)),'descend');
    cut2 = NN(ceil(numel(NN)*.05));
    
    
    
    
else
    
    if exist(fullfile(pwd,'MACM',project,'NullDistributions',[ study '_clustP.mat']),'file')~=2
        
        fprintf(1,'%s\n',[study ' - simulating noise'])
        toRepeat = 5000;
        N        = cell(1,toRepeat);
        NM       = nan(1,toRepeat);
        NN       = nan(1,toRepeat);
        
        load(fullfile(pwd,'BrainMapData','permSpace.mat'))
        nowIndices = indices;
        totalVoxel = numel(indices);
        AnzXYZ = anzXYZ;
        
        xleer      = single(zeros(TEMPLATE.dim+[30 30 30]));
        
        Smoothing = [Experiments.Smoothing];
        Peaks     = [Experiments.Peaks];
        kernel    = zeros(31,31,31);  kernel(16,16,16) = 1;
        smte      = struct('dim',[31 31 31],'mat',TEMPLATE.mat);
        clear Experiments
        
        tic
        for xi=1:ceil(toRepeat/500)
            parfor runde = ((xi-1)*500)+1:min((xi*500),toRepeat)
                
                Vx         = single(nan(AnzV,totalVoxel));
                for i=1:AnzV
                    stamp = single(MemSmooth64bit(kernel,Smoothing(i),smte,zeros(31)));
                    nowXYZ = allXYZ(:,ceil(rand(1,Peaks(i))*AnzXYZ));
                    data   = xleer;
                    for ii = 1:Peaks(i)
                        data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30) = ...
                            max(data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30),stamp);
                    end
                    Vx(i,:) = (data(nowIndices));
                end
                
                data  = 1-prod(1-Vx);
                p     = cNULL(round(data*step)+1);
                
                NM(runde) = max(data(:));
                A = spm_clusters(double(allXYZ(1:3,p<uc)));
                
                if isempty(A)
                    Q = 0;
                else
                    Q = hist(A,1:max(A));
                end
                
                NN(runde) = max(Q);
                N{runde}  = Q;
            end
            fprintf(1,'%s\n',[int2str(xi*500) ' finished in ' num2str(toc/60,'%3.1f') ' minutes'])
        end
        
        N = [N{:}];
        N = sort(N(~isnan(N)),'descend');
        cut = N(ceil(numel(N)*.05));
        
        NN = sort(NN(~isnan(NN)),'descend');
        cut2 = NN(ceil(numel(NN)*.05));
        save(fullfile(pwd,'MACM',project,'NullDistributions',[ study '_clustP.mat']),'N','NM','NN','cut','cut2')
        
    end
    
    
end


clear Vi allXYZ



load(fullfile(pwd,'MACM',project,'NullDistributions',[study '_clustP.mat']))
N = sort(N(~isnan(N)),'descend');
cut = N(ceil(numel(N)*.05));

NN = sort(NN(~isnan(NN)),'descend');
cut2 = NN(ceil(numel(NN)*.05));


fprintf(1,'%s\n',[study ' - inference and printing'])


VZ = spm_vol(fullfile(pwd,'MACM',project,'ALEvolumesZ',[ study '.nii']));          Z = spm_read_vols(VZ);
Z(prior == 0) = 0;      Z(Z < spm_invNcdf(1-uc,0,1)) =   0;

if any(Z(:)); XYZ = []; zz = [];
    for p = 1:VZ.dim(3); d = Z(:,:,p);
        if any(any(d)); [i,j] = find(d>0); XYZ = [XYZ [i'; j'; p*ones(1,size(j,1))]]; zz = [zz d(find(d>0))']; end
    end;
    
    A = spm_clusters(XYZ);  Q = zeros(1,max(A));  for i = 1:max(A); Q(i) = sum(A == i); end
    writeXYZ = []; writeZ   = []; mini = Inf;
    
    if max(Q)>10
        [N I] = sort(Q,'descend');
        
        for i=1:numel(I)
            if N(i)>=cut2
                mini = min(mini,N(i));
                writeXYZ    = [writeXYZ XYZ(:,A==I(i))];
                writeZ      = [writeZ zz(A==I(i))];
            end
            
        end
        
        if numel(writeXYZ)>0
            Vo          = VZ;
            Vo.fname    = fullfile(pwd,'MACM',project,'Results',[ study '_cFWE05_001_' int2str(mini) '.nii']);
            Vo = spm_create_vol(Vo);
            for p = 1:Vo.dim(3)
                Q = find(writeXYZ(3,:) == p);
                Vo = spm_write_plane(Vo, full(sparse(writeXYZ(1,Q),writeXYZ(2,Q),writeZ(Q),Vo(1).dim(1),Vo(1).dim(2))), p);
            end
            se_render_imageCol(Vo(1).fname,0,0,col)
            print('-dpng',fullfile(pwd,'MACM',project,'Images',[spm_str_manip(Vo(1).fname,'rt') '.png']))
            ImageCut(fullfile(pwd,'MACM',project,'Images',[spm_str_manip(Vo(1).fname,'rt') '.png']),'X');
            delete(fullfile(pwd,'MACM',project,'Images',[spm_str_manip(Vo(1).fname,'rt') '.png']))
        end
        
    end
end

