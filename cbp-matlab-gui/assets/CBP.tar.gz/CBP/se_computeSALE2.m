function se_computeSALE2(Experiments,study, col, project)


TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));
prior    = spm_read_vols(TEMPLATE)>.1;

if nargin<3
    col = NaN;
end

if nargin<4
    project = '';
end


uc  = 0.001;

[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'SALE2'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'SALE2','Images'));
[~,~,~] =mkdir(fullfile(pwd,'MACM',project,'ALESALE','Images'));
AnzV     = numel(Experiments);

mB = 1;
for i=1:AnzV
    mB = mB*(1-max(Experiments(i).Kernel(:)));
end

bin = [0:.0001:(1-mB)+.001];
step  = 1/mean(diff(bin));




fprintf(1,'%s\n',[study ' - simulating expectancy'])

load(fullfile(pwd,'MACM',project,'NullDistributions',[ study '.mat']))

toRepeat = 10000;
load(fullfile(pwd,'BrainMapData','permSpace.mat'))
total   = size(allBM,2);
indices = find(padarray(prior,[15 15 15]));
xleer      = zeros(TEMPLATE.dim+[30 30 30]);
Vi         = single(nan(AnzV,numel(indices)));

fx = dir(fullfile(pwd,'MACM',project,'ALEvolumes',[study '.nii']));
ALE = padarray(spm_read_vols(spm_vol(fullfile(pwd,'MACM',project,'ALEvolumes',fx(1).name))),[15 15 15]);
ALE = ALE(indices)';

try
    load(fullfile(pwd,'MACM',project,'NullDistributions',[study '_clustS.mat']));
    StartRunde = runde;
catch
    A        = zeros(1,numel(indices));
    NM       = nan(1,toRepeat);
    NN       = nan(1,toRepeat);
    clusters = 1;
    StartRunde     = 1;
end



tic
for runde = StartRunde+1:toRepeat
    
    allBMf = allBM;
    parfor i=1:AnzV
        nowXYZ = allBMf(:,randsample(total,Experiments(i).Peaks));
        data   = xleer;
        for ii = 1:Experiments(i).Peaks
            data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30) = ...
                max(data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30),Experiments(i).Kernel);
        end
        Vi(i,:) = (data(indices));
    end
    
    data  = 1-prod(1-Vi);
    A = A+double(data>=ALE);
    
    if rem(runde,100)==0
        fprintf(1,'%s\n',['Iteration ' int2str(runde) ' reached after ' num2str(toc/60,'%3.2f') ' min']);
        save(fullfile(pwd,'MACM',project,'NullDistributions',[ study '_clustS.mat']),'A','runde')
    end
end


A = spm_invNcdf(1-(A/toRepeat),0,1);
A(isinf(A) & A>0) = spm_invNcdf(1-eps,0,1)+ALE(isinf(A) & A>0);

data   = xleer;
data(indices) = A;
data    = data(16:end-15,16:end-15,16:end-15);



fprintf(1,'%s\n',['Inference and printing'])
xVo        = TEMPLATE;
xVo.dt     = [64 1];
xVo        = rmfield(xVo,'pinfo'); x = num2str(1-uc);
xVo.fname  = fullfile(pwd,'MACM',project,'SALE2',[ study '.nii']);
xVo        = spm_write_vol(xVo,data);
xVo        = rmfield(xVo,'pinfo');
xVo.fname  = fullfile(pwd,'MACM',project,'SALE2',[ study '_' x(3:end) '.nii']);
xVo        = spm_write_vol(xVo,data.*(data>spm_invNcdf(1-uc,0,1)));

try
    se_render_imageCol(fullfile(pwd,'MACM',project,'SALE2',[ study '_' x(3:end) '.nii']),spm_invNcdf(1-uc,0,1),20,col)
    print('-dpng',fullfile(pwd,'MACM',project,'SALE2','Images',[ study '_' x(3:end) '.png']))
    ImageCut(fullfile(pwd,'MACM',project,'SALE2','Images',[ study '_' x(3:end) '.png']),'X');
    delete(fullfile(pwd,'MACM',project,'SALE2','Images',[ study '_' x(3:end) '.png']));
end


fx = dir(fullfile(pwd,'MACM',project,'ALEvolumesZ',[study '.nii']));
ALE = padarray(spm_read_vols(spm_vol(fullfile(pwd,'MACM',project,'ALEvolumesZ',fx(1).name))),[15 15 15]);
ALE = ALE(indices)';

data   = xleer;
data(indices) = min(A,ALE);
data    = data(16:end-15,16:end-15,16:end-15);


load(fullfile(pwd,'MACM',project,'NullDistributions',[study '_clustP.mat']));
NN = sort(NN(~isnan(NN)),'descend');
cut2 = NN(ceil(numel(NN)*.05));

xVo        = TEMPLATE;
xVo.dt     = [64 1];
xVo        = rmfield(xVo,'pinfo'); x = num2str(1-uc);
xVo.fname  = fullfile(pwd,'MACM',project,'ALESALE',[ study '.nii']);
xVo        = spm_write_vol(xVo,data);
xVo        = rmfield(xVo,'pinfo');
xVo.fname  = fullfile(pwd,'MACM',project,'ALESALE',[ study '_' x(3:end) '.nii']);
xVo        = spm_write_vol(xVo,data.*(data>spm_invNcdf(1-uc,0,1)));



data = data.*(data>spm_invNcdf(1-uc,0,1));
ind = find(data);
XYZ = []; Z = data(ind);
[XYZ(:,1) XYZ(:,2) XYZ(:,3)] = ind2sub(xVo.dim,ind);
A = spm_clusters(XYZ'); Q = [];
for i = 1:max(A); j = find(A == i); if length(j) >= cut2; Q = [Q j]; end; end
Z = Z(Q); XYZ = XYZ(Q,:);

xVo        = TEMPLATE;
xVo.dt     = [64 1];
xVo        = rmfield(xVo,'pinfo'); x = num2str(uc);
xVo.fname  = fullfile(pwd,'MACM',project,'ALESALE',[ study '_' x(3:end) '_' int2str(cut2) '.nii']);
xVo        = spm_write_vol(xVo,accumarray(XYZ(:,1:3),Z',xVo.dim));

try
    se_render_imageCol(fullfile(pwd,'MACM',project,'ALESALE',[ study '_' x(3:end) '_' int2str(cut2) '.nii']),spm_invNcdf(1-uc,0,1),cut2,col)
    print('-dpng',fullfile(pwd,'MACM',project,'ALESALE','Images',[ study '_' x(3:end) '_' int2str(cut2) '.png']))
    ImageCut(fullfile(pwd,'MACM',project,'ALESALE','Images',[ study '_' x(3:end) '_' int2str(cut2) '.png']),'X');
    delete(fullfile(pwd,'MACM',project,'ALESALE','Images',[ study '_' x(3:end) '_' int2str(cut2) '.png']));
end

