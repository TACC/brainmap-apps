ROIs = se_select(Inf,'vois','Select mask-images or VOI-definition matfiles');

load(fullfile(pwd,'BrainMapData','Tasks.mat'))

for xi=1:size(ROIs,1)
    load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
    ROInow = deblank(ROIs(xi,:));
    if ~strcmpi(ROInow(end-2:end),'mat')
        job = struct('VOIs',cell(1,1),'within',1,'between',1,'Distance',0,'Number',0,'FilterIn',zeros(1,numel(AllBD)),'FilterOut',zeros(1,numel(AllBD)));
        job(1).VOIs{1} = ROInow;
    else
        load(ROInow)
    end
    
    if ~isfield(job,'col'); job(1).col = NaN; end
    inFoci = se_parseJob(job, XYZ2EXP, AllBD);
    Experiments = Experiments(inFoci>0);
    save(strrep(ROInow,'nii','mat'),'Experiments');
end