clc, clear



% Load and sort map-image
Vi = spm_vol(fullfile(pwd,'MaskenEtc','Schaefer_400_FSLMNI2mm.nii'));
dat = round(spm_read_vols(Vi)); ind  = find(spm_read_vols(Vi)>0); [X, Y, Z] = ind2sub(Vi.dim,ind); label = dat(ind); clear dat
VOImm  = Vi.mat * [X Y Z ones(size(Z))]'; clear X Y Z ind
labels = unique(label);
AnzR = numel(labels);  

tic
% load BrainMap data
load(fullfile(pwd,'BrainMapData','MetaMappingAnalysis.mat'))
load(fullfile(pwd,'BrainMapData','MetaMappingCBP.mat'))

TEMPLATE = spm_vol(fullfile(pwd,'MaskenEtc','Grey10.nii'));

allXYZmm = single(TEMPLATE.mat * [allXYZ; ones(1,size(allXYZ,2))]); 
allBM    = int16(allBM(1:3,:));
VOImm    = single(VOImm);
samples  = size(allBM,2);
anzXYZ   = numel(indices);

for roi1 = 1:numel(labels)
    [ids,dis] = yael_nn(allXYZmm(1:3,:), VOImm(1:3,label==labels(roi1)), 1, 2);
    voxel{roi1} = (ids(dis==0));
end

Q = unique(cell2mat(voxel));
indices = indices(Q);
allXYZmm = allXYZmm(:,Q);
anzXYZ   = numel(indices);

for roi1 = 1:numel(labels)
    [ids,dis] = yael_nn(allXYZmm(1:3,:), VOImm(1:3,label==labels(roi1)), 1, 2);
    voxel{roi1} = (ids(dis==0));
end

toc

%%

xleer = single(zeros(TEMPLATE.dim+[30 30 30]));
AnzN  = numel(Experiments);
Vx(1,1) = 0; Vx(AnzN,anzXYZ) = 0; Vx = single(Vx);


Peaks     = [Experiments.Peaks];
kernel    = zeros(31,31,31);  kernel(16,16,16) = 1;
smte      = struct('dim',[31 31 31],'mat',TEMPLATE.mat);
for i=1:numel(Experiments)
    XYZ{i} = Experiments(i).XYZ;
end

Smoothing = [Experiments.Smoothing];
Smoothers = unique(Smoothing);
for i=1:numel(Smoothers)
    stamps{i} = single(MemSmooth64bit(kernel,Smoothers(i),smte,zeros(31)));
end

parfor i=1:AnzN; Smoothing(i) = find(Smoothers == Smoothing(i)); end


clear Experiments
parfor i=1:AnzN
    stamp = stamps{Smoothing(i)}; nowXYZ = XYZ{i}; data   = xleer;
    for ii = 1:Peaks(i)
        data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30) = ...
            max(data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30),stamp);
    end
    Vx(i,:) = (data(indices));
end

ExperimentByROI(1,1) = 0; ExperimentByROI(AnzN, AnzR) = 0;
for roi1 = 1:numel(labels)
    ExperimentByROI(:,roi1) = mean(Vx(:,voxel{roi1}),2);
end
ExperimentByROI(ExperimentByROI<0.0001) = 0;

leer = zeros(1,AnzR);
MACM = eye(AnzR,'single');
for roi1 = 1:AnzR-1
    vec1 = ExperimentByROI(:,roi1); nulls = leer;
    for roi2 = roi1+1:AnzR
        nulls(roi2) = 1-(prod(1-(vec1.*ExperimentByROI(:,roi2))));
    end
    MACM(roi1,:) = nulls;
end


%%


tic
for repeat=1:10000
   Vx(1,1) = 0; Vx(AnzN,anzXYZ) = 0; Vx = single(Vx);
    parfor i=1:AnzN
        stamp = stamps{Smoothing(i)}; data = xleer; nowXYZ = allBM(:,randi(samples,Peaks(i),1));
        for ii = 1:Peaks(i)
            data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30) = max(data(nowXYZ(1,ii):nowXYZ(1,ii)+30,nowXYZ(2,ii):nowXYZ(2,ii)+30,nowXYZ(3,ii):nowXYZ(3,ii)+30),stamp);
        end; Vx(i,:) = (data(indices));
    end    
    
    ExperimentByROI(1,1) = 0; ExperimentByROI(AnzN, AnzR) = 0; 
    for roi1 = 1:numel(labels)
        ExperimentByROI(:,roi1) = mean(Vx(:,voxel{roi1}),2);
    end
    ExperimentByROI(ExperimentByROI<0.0001) = 0;
    
    Null = eye(AnzR,'single');
    for roi1 = 1:AnzR-1
        vec1 = ExperimentByROI(:,roi1); nulls(1) = 0; nulls(AnzR) = 0;
        for roi2 = roi1+1:AnzR
            nulls(roi2) = 1-(prod(1-(vec1.*ExperimentByROI(:,roi2))));
        end
        Null(roi1,:) = nulls;       
    end
    NullMACM(:,:,repeat) = (Null);
    
    if rem(repeat,100)==0
        save MACMnull NullMACM repeat MACM
        fprintf(1,'%s\n',['Iteration ' int2str(repeat) ': ' int2str(floor(toc/3600)) ' h' ' ' int2str(rem(toc,3600)/60) ' min'])
    end
    
end

NullMACM(:,:,end+1) = MACM;

save


p = mean(NullMACM>=MACM,3);

Z = norminv(mean(NullMACM<MACM,3));
Z(Z<0) = 0;

imagesc(Z)





