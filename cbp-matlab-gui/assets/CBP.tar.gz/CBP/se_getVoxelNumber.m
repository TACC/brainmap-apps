clc

Vi = spm_vol(spm_select(Inf,'nifti','Select images'));
u = spm_input('Threshold');

for i=1:numel(Vi)
    fprintf('%s\n',[Vi(i).fname ': '  num2str(abs(det(Vi(i).mat)) *sum(sum(sum(spm_read_vols(Vi(i))>u))),'%4.1f') ' mm3'])
end
