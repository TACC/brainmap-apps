function se_makeWorkspace(Eperis,study, project)

warning off

if nargin<3
    project = '';
end


[s,mess,messid] =mkdir(fullfile(pwd,'MACM',project,'Workspaces'));


if isfield(Eperis,'BMid');

    ID = unique([Eperis.BMid]);

    fid = fopen(fullfile(pwd,'MACM',project,'Workspaces',['id_' study '.xml']),'wt');




    fprintf(fid,'%s\n','<?xml version="1.0" encoding="UTF-8" standalone="no"?>');
    fprintf(fid,'%s\n','<!DOCTYPE workspace SYSTEM "http://www.brainmap.org/DTDs/Workspace-1.0.dtd">');
    fprintf(fid,'%s\n','<workspace>');
    fprintf(fid,'%s\n','<color><colorName>Black</colorName><r>0</r><g>0</g><b>0</b></color>');

    for i=1:numel(ID)
        fprintf(fid,'%s\n','<simplePaper>');
        fprintf(fid,'%s\n',['<id>' int2str(ID(i)) '</id><colorName>Black</colorName><shape>Small Square</shape><shown/>' ] );
        ids = [Eperis([Eperis.BMid] == ID(i)).EXid];

        for ii=1:numel(ids)
            fprintf(fid,'%s\n',['<simpleExperiment><name>ExpID=' int2str(ids(ii)) '</name><shown/></simpleExperiment>' ] );
        end

        fprintf(fid,'%s\n','</simplePaper>');
    end
    fprintf(fid,'%s\n','</workspace>');

    status = fclose(fid);

end