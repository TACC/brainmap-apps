function inFoci = se_parseJob(job, XYZ2EXP, AllBD);

job  = job(cellfun('length',{job.VOIs})>0);
tmp  = nan(numel(job),max(XYZ2EXP(4,:)));

for i=1:numel(job)
    
    tmp1 = nan(size(job(1).VOIs{1},1),max(XYZ2EXP(4,:)));
    
    for ii=1:size(job(i).VOIs{1},1)
        if length(deblank(job(i).VOIs{1}(ii,:)))>3
            
            name = deblank(job(i).VOIs{1}(ii,:));
            if name(end)=='1'
                name = strrep(name,',1','');
            end
            if max(strcmpi(name(end-2:end),{'img','nii','hdr'}))>0
                try
                    Vi      = spm_vol(deblank(job(i).VOIs{1}(ii,:)));
                catch
                    sx = strfind(deblank(job(i).VOIs{1}(ii,:)),'VOIfiles');
                    Vi = spm_vol(fullfile(pwd,'VOIs',strrep(deblank(job(i).VOIs{1}(ii,sx:end)),'\',filesep)));
                end
                ind     = find(spm_read_vols(Vi)>0);
                [X Y Z] = ind2sub(Vi.dim,ind);
                VOImm  = Vi.mat * [X Y Z ones(size(Z))]'; clear X Y Z ind
            else
                VOImm = str2num(job(i).VOIs{1}(ii,:))'; 
                Vi.mat = eye(3);
            end
            
            [A D] = knnsearch(VOImm(1:3,:)',XYZ2EXP(1:3,:)');
            
            if sum(((floor(D)-abs(det(Vi.mat(1:3,1:3)))^(1/3))<=job(i).Distance))<job(i).Number
                [buffer Q]      = sort(D,'ascend');
                Q = Q(1:round(max(job(i).Number,sum(((floor(D)-abs(det(Vi.mat(1:3,1:3)))^(1/3)))<=0))*1.25));
                w = spm_Npdf(sqrt(D(Q))',0,XYZ2EXP(5,Q));
                [buffer, m] = unique(XYZ2EXP(4,Q),'first');
                [w II]      = sort(w(m),'descend');
                tmp1(ii,:) = 0;
                tmp1(ii,buffer(II(1:job(i).Number))) = 1;
            else
                tmp1(ii,:) = 0;
                tmp1(ii,XYZ2EXP(4,((floor(D)-abs(det(Vi.mat(1:3,1:3)))^(1/3))<=job(i).Distance))) = 1;
            end
        else
            tmp1(ii,:) = [];
        end
    end
    
    if numel(tmp1)>0
        if job(i).within == 1
            tmp(i,:) = nanmin(tmp1,[],1);
        else
            tmp(i,:) = nanmax(tmp1,[],1);
        end
    else
        tmp(i,:) = [];
    end
end


if job(1).between == 1
    inFoci = nanmin(tmp,[],1);
else
    inFoci = nanmax(tmp,[],1);
end
inFoci(isnan(inFoci)) = 0;

if sum(job(1).FilterIn)>0
    tmp1 = zeros(sum(job(1).FilterIn),max(XYZ2EXP(4,:)));
    wer = find(job(1).FilterIn);
    for in = 1:numel(wer);
        tmp1(in,AllBD(wer(in)).Experiments) = 1;
    end
    tmp = max(tmp1,[],1);
    inFoci(tmp<1) = 0;
end

if sum(job(1).FilterOut)>0
    tmp1 = zeros(sum(job(1).FilterOut),max(XYZ2EXP(4,:)));
    wer = find(job(1).FilterOut);
    for in = 1:numel(wer);
        tmp1(in,AllBD(wer(in)).Experiments) = 1;
    end
    tmp = max(tmp1,[],1);
    inFoci(tmp>0) = 0;
end

