clc, clear

figure(1); load MACMnull.mat; NullMACM(:,:,end+1) = MACM; NullMACM(:,:,end+1) = 0;

Z = norminv(mean(NullMACM<MACM,3)); Z(MACM==0) = 0;
for i=1:size(MACM,1)-1; for ii=i+1:size(MACM,1); MACM(ii,i) = MACM(i,ii); Z(ii,i) = Z(i,ii); end; end


Z(eye(size(Z))==1) = max(Z(:)); Z2 = MACM.*(Z==max(Z(:))); 
r = reord(Z.*(Z>0),2); Z2 = Z2(r,r); Z2 = Z2.*(triu(ones(size(Z)),1)>0);
subplot(2,3,2); imagesc(Z2,[min(Z2(triu(MACM,1)>0 & Z2>0))/2 min(Z2(triu(MACM,1)>0 & Z2>0))*20]), colormap(gca,hot)
view(gca,[-45 90]); title('MACM thresholded')

subplot(2,3,1); M2 = MACM(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[0 min(Z2(triu(MACM,1)>0 & Z2>0))*10]), colormap(gca,hot)
view(gca,[-45 90]); title('MACM')

subplot(2,3,3); M2 = Z(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[0 3]), colormap(gca,hot)
view(gca,[-45 90]); title('Z-score')

subplot(2,3,6); M2 = Z(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[-3 3]), colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; [0 0 0]; [linspace(0,1,100); linspace(0,0,100); linspace(0,0,100)]'])
view(gca,[-45 90]); title('Z-score +/-')

Q = triu(ones(size(Z)),1)>0 & MACM>0 & Z>0;
subplot(2,3,4); histogram(Z(Q)) 
subplot(2,3,5); binscatter(MACM(Q),Z(Q)); axis tight



figure(2); clf;  

subplot(2,3,4); M2 = Z(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[-3 3]), colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; [0 0 0]; [linspace(0,1,100); linspace(0,0,100); linspace(0,0,100)]'])
view(gca,[-45 90]); title('Z-score +/-')


scaleMACM = MACM./mean(NullMACM,3); scaleMACM(scaleMACM>5) = 5;
for i=1:size(MACM,1)-1; for ii=i+1:size(MACM,1); scaleMACM(ii,i) = scaleMACM(i,ii); end; end

scaleMACM(eye(size(scaleMACM))==1) = max(scaleMACM(:)); % r = reord(scaleMACM,2);

subplot(2,3,2); histogram(scaleMACM(triu(scaleMACM,1)>0));  title('MACM scaled')
scaleMACM = scaleMACM(r,r); scaleMACM = scaleMACM.*(triu(ones(size(Z)),1)>0);
subplot(2,3,5); imagesc(scaleMACM,[0 5]), colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; zeros(20,3); [linspace(0,1,500); linspace(0,0,500); linspace(0,0,500)]'])
view(gca,[-45 90]); title('MACM scaled')



scaleMACM = (MACM-mean(NullMACM,3))./std(NullMACM,[],3); scaleMACM(abs(scaleMACM)>10) = 10*sign(scaleMACM(abs(scaleMACM)>10));
for i=1:size(MACM,1)-1; for ii=i+1:size(MACM,1); scaleMACM(ii,i) = scaleMACM(i,ii); end; end

scaleMACM(eye(size(scaleMACM))==1) = max(scaleMACM(:)); % r = reord(scaleMACM+10,2);

subplot(2,3,3); histogram(scaleMACM(triu(scaleMACM,1)~=0));  title('MACM Z')
scaleMACM = scaleMACM(r,r); scaleMACM = scaleMACM.*(triu(ones(size(Z)),1)>0);
subplot(2,3,6); imagesc(scaleMACM,[0 5]), colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; zeros(20,3); [linspace(0,1,100); linspace(0,0,100); linspace(0,0,100)]'])
view(gca,[-45 90]); title('MACM Z')




% 
% figure(2); load MACMnullFlat.mat; NullMACM(:,:,end+1) = MACM; NullMACM(:,:,end+1) = 0;
% 
% Z = norminv(mean(NullMACM<MACM,3)); Z(MACM==0) = 0;
% for i=1:size(MACM,1)-1; for ii=i+1:size(MACM,1); MACM(ii,i) = MACM(i,ii); Z(ii,i) = Z(i,ii); end; end
% 
% Z(eye(size(Z))==1) = max(Z(:)); Z2 = MACM.*(Z==max(Z(:))); 
% r = reord(Z.*(Z>0),2); Z2 = Z2(r,r); Z2 = Z2.*(triu(ones(size(Z)),1)>0);
% subplot(2,3,2); imagesc(Z2,[min(Z2(triu(MACM,1)>0 & Z2>0)) min(Z2(triu(MACM,1)>0 & Z2>0))*25]), colormap(gca,hot)
% view(gca,[-45 90]); title('MACM thresholded')
% 
% subplot(2,3,1); M2 = MACM(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[0 min(Z2(triu(MACM,1)>0 & Z2>0))*10]), colormap(gca,hot)
% view(gca,[-45 90]); title('MACM')
% 
% subplot(2,3,3); M2 = Z(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[0 3]), colormap(gca,hot)
% view(gca,[-45 90]); title('Z-score')
% 
% subplot(2,3,6); M2 = Z(r,r); M2 = M2.*(triu(ones(size(Z)),1)>0); imagesc(M2,[-3 3]), colormap(gca,[[linspace(0,0,100); linspace(0,0,100); linspace(0,1,100)]'; [0 0 0]; [linspace(0,1,100); linspace(0,0,100); linspace(0,0,100)]'])
% view(gca,[-45 90]); title('Z-score +/-')
% 
% Q = triu(ones(size(Z)),1)>0 & MACM>0 & Z>0;
% subplot(2,3,4); histogram(Z(Q)) 
% subplot(2,3,5); binscatter(MACM(Q),Z(Q)); axis tight
% 












Vi = spm_vol(fullfile(pwd,'MaskenEtc','Schaefer_400_FSLMNI2mm.nii'));
dat = round(spm_read_vols(Vi)); ind  = find(spm_read_vols(Vi)>0); [X, Y, Z] = ind2sub(Vi.dim,ind); label = dat(ind); 
labels = unique(label);

[x y] = find(Z2 == max(Z2(:)));

out = zeros(size(dat));
out(dat==labels(x)) = 1; out(dat==labels(y)) = 2;
Vo       = Vi; Vo.fname = fullfile('MACMmax1.nii');
Vo.dt    = [64 1]; Vo       = rmfield(Vo,'pinfo');
Vo       = spm_write_vol(Vo,out); se_render_imageCol(Vo(1).fname,0,0,nan)



