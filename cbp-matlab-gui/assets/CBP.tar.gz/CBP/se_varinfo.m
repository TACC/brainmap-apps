function dvi = se_varinfo(L1,L2)

T1 = tabulate(L1); pi = T1(:,3)/100;
E1 = -sum(pi.*log(pi));

T2 = tabulate(L2); pj = T2(:,3)/100;
E2 = -sum(pj.*log(pj));

I = 0;
for i = 1:size(T1,1)
    for j = 1:size(T2,1)
        pij = sum((L1 == T1(i,1)).*(L2 == T2(j,1)))/numel(L1);

        if (pij > 0)
            I = I + pij*log(pij/(pi(i)*pj(j)));
        end
    end
end

dvi = E1 + E2 - 2*I;